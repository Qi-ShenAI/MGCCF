import os
import argparse

from utils.functions import Storage

class ConfigRegression():
    def __init__(self, args):
        self.globalArgs = args
        # hyper parameters for models
        HYPER_MODEL_MAP = {
            'cirp': self.__CIR,
            'cirp-dcr': self.__CIR,
            'myasrmodel_post_bert': self.__MyASRmodel_post_bert,
            'mymodel_post_bert': self.__MyASRmodel_post_bert,
            #####################
            'myasrmodel_post_bert_wo_cucl': self.__MyASRmodel_post_bert,
            'myasrmodel_post_bert_wo_ftcl': self.__MyASRmodel_post_bert,
            'myasrmodel_post_bert_wo_ib': self.__MyASRmodel_post_bert,
            'myasrmodel_post_bert_wo_gci': self.__MyASRmodel_post_bert,
            'myasrmodel_post_bert_wo_micf': self.__MyASRmodel_post_bert,
            'mymodel_wo_cucl': self.__MyASRmodel,
            'mymodel_wo_ftcl': self.__MyASRmodel,
            'mymodel_wo_ib': self.__MyASRmodel,
            'mymodel_wo_gci': self.__MyASRmodel,
            'mymodel_wo_micf': self.__MyASRmodel,
            #####################
            'myasrmodel': self.__MyASRmodel,
            'mymodel': self.__MyASRmodel,
            'swrm': self.__SWRM,
            'swrmbase': self.__SWRM,
            'mult': self.__MULT,
            'misa': self.__MISA,
            'self_mm': self.__SELF_MM,
            'emt_dlfr': self.__EMT_DLFR,

        }
        # hyper parameters for datasets
        HYPER_DATASET_MAP = self.__datasetCommonParams()

        # normalize
        model_name = str.lower(args.modelName)
        dataset_name = str.lower(args.datasetName)
        # load params
        commonArgs = HYPER_MODEL_MAP[model_name]()['commonParas']
        dataArgs = HYPER_DATASET_MAP[dataset_name]

        dataArgs = dataArgs['aligned'] if (commonArgs['need_data_aligned'] and 'aligned' in dataArgs) else dataArgs['unaligned']

            
        # integrate all parameters
        self.args = Storage(dict(vars(args),
                            **dataArgs,
                            **commonArgs,
                            **HYPER_MODEL_MAP[model_name]()['datasetParas'][dataset_name],
                            ))

    def __datasetCommonParams(self):
        from config.get_data_root import data_root
        # NOTE: change the dataset_path to your own path!
        dataset_path = data_root
        root_dataset_dir = os.path.join(dataset_path, 'datasets')
        # print(root_dataset_dir)
        # exit()
        tmp = {
            'mosi':{
                "aligned": {
                    "featurePath": "MOSI/Processed/aligned_50.pkl",
                    "seq_lens": [50, 50, 50],
                    "feature_dims": [768, 5, 20],
                    "train_samples": 1284,
                    "num_classes": 3,
                    "language": "en",
                    "KeyEval": "Loss"
                },
                'unaligned': {
                    'dataPath': os.path.join(root_dataset_dir, 'MOSI/Processed/unaligned_50.pkl'),
                    'seq_lens': None,
                    # (text, audio, video)
                    'feature_dims': (768, 5, 20),
                    'train_samples': 1284,
                    'num_classes': 3,
                    'language': 'en',
                    'KeyEval': 'Loss',
                    'missing_seed': (111, 1111, 11111),
                }

            },
            'mosei': {
                'aligned': {
                    'dataPath': os.path.join(root_dataset_dir, 'MOSEI/Processed/aligned_50.pkl'),
                    # 'dataPath': os.path.join(root_dataset_dir, 'MOSEI/aligned_50.pkl'),
                    'seq_lens': (50, 50, 50),
                    # (text, audio, video)
                    'feature_dims': (768, 74, 35),
                    'train_samples': 16326,
                    'num_classes': 3,
                    'language': 'en',
                    'KeyEval': 'Loss',
                    'missing_seed': (111, 1111, 11111),
                },
                'unaligned': {
                    'dataPath': os.path.join(root_dataset_dir, 'MOSEI/Processed/unaligned_50.pkl'),
                    # 'dataPath': os.path.join(root_dataset_dir, 'MOSEI/unaligned_50.pkl'),
                    'seq_lens': (50, 500, 375),
                    # (text, audio, video)
                    'feature_dims': (768, 74, 35),
                    'train_samples': 16326,
                    'num_classes': 3,
                    'language': 'en',
                    'KeyEval': 'Loss',
                    'missing_seed': (111, 1111, 11111),
                },
                'aligned_missing': {
                    'dataPath': os.path.join(root_dataset_dir, 'MOSEI/Processed/aligned_50.pkl'),
                    # 'dataPath': os.path.join(root_dataset_dir, 'MOSEI/aligned_50.pkl'),
                    'seq_lens': (50, 50, 50),
                    # (text, audio, video)
                    'feature_dims': (768, 74, 35),
                    'train_samples': 16326,
                    'num_classes': 3,
                    'language': 'en',
                    'KeyEval': 'Loss',
                    # 'missing_rate': (0.0, 0.0, 0.0),
                    'missing_seed': (111, 1111, 11111),
                },
                'unaligned_missing': {
                    'dataPath': os.path.join(root_dataset_dir, 'MOSEI/Processed/unaligned_50.pkl'),
                    # 'dataPath': os.path.join(root_dataset_dir, 'MOSEI/unaligned_50.pkl'),
                    'seq_lens': (50, 500, 375),
                    # (text, audio, video)
                    'feature_dims': (768, 74, 35),
                    'train_samples': 16326,
                    'num_classes': 3,
                    'language': 'en',
                    'KeyEval': 'Loss',  # Loss(pred_m)
                    # 'missing_rate': (0.1, 0.1, 0.1),
                    'missing_seed': (111, 1111, 11111),
                }
            },
            'con_sims':{
                'unaligned': {
                    # 'dataPath': os.path.join(root_dataset_dir, 'SIMS/Processed/unaligned_39.pkl'),
                    'dataPath': os.path.join(root_dataset_dir, f'SIMS/Processed/unaligned_39{"" if not self.globalArgs.use_normalized_data else "_normalized"}.pkl'),
                    # (batch_size, seq_lens, feature_dim)
                    'seq_lens': (39, 400, 55), # (text, audio, video) 50, 925, 232 50, 375, 500  39, 400, 55
                    'feature_dims': (768, 33, 709), # (text, audio, video) 709
                    'train_samples': 1368,
                    'num_classes': 3,
                    'language': 'cn',
                    'KeyEval': 'Loss',#Loss(pred_m)
                    'missing_seed': (111, 1111, 11111),
                }
            },
            'asr_speechbrain_mosi': {
                'unaligned': {
                    'dataPath': os.path.join(root_dataset_dir, 'MOSI/Processed/asr_speechbrain_unaligned_50.pkl'),
                    'seq_lens': None,
                    # (text, audio, video)
                    'feature_dims': (768, 5, 20),
                    'train_samples': 1284,
                    'num_classes': 3,
                    'language': 'en',
                    'KeyEval': 'Loss',
                    'missing_seed': (111, 1111, 11111),
                }
            },
            'asr_ibm_mosi': {
                'unaligned': {
                    'dataPath': os.path.join(root_dataset_dir, 'MOSI/Processed/asr_ibm_unaligned_50.pkl'),
                    'seq_lens': None,
                    # (text, audio, video)
                    'feature_dims': (768, 5, 20),
                    'train_samples': 1284,
                    'num_classes': 3,
                    'language': 'en',
                    'KeyEval': 'Loss',
                    'missing_seed': (111, 1111, 11111),
                }
            },
            'asr_xf_mosi': {
                'unaligned': {
                    'dataPath': os.path.join(root_dataset_dir, 'MOSI/Processed/asr_xf_unaligned_50.pkl'),
                    'seq_lens': None,
                    # (text, audio, video)
                    'feature_dims': (768, 5, 20),
                    'train_samples': 1284,
                    'num_classes': 3,
                    'language': 'en',
                    'KeyEval': 'Loss',
                    'missing_seed': (111, 1111, 11111),
                }
            },

            'asr_speechbrain_mosei': {
                'unaligned': {
                    'dataPath': os.path.join(root_dataset_dir, 'MOSI/Processed/asr_speechbrain_unaligned_mosei_50.pkl'),
                    'seq_lens': (50, 500, 375),
                    # (text, audio, video)
                    'feature_dims': (768, 74, 35),
                    'train_samples': 16326,
                    'num_classes': 3,
                    'language': 'en',
                    'KeyEval': 'Loss',  # Loss(pred_m)
                    # 'missing_rate': (0.1, 0.1, 0.1),
                    'missing_seed': (111, 1111, 11111),
                }
            },

            'asr_ibm_mosei': {
                'unaligned': {
                    'dataPath': os.path.join(root_dataset_dir, 'MOSI/Processed/asr_ibm_unaligned_mosei_50.pkl'),
                    'seq_lens': (50, 500, 375),
                    # (text, audio, video)
                    'feature_dims': (768, 74, 35),
                    'train_samples': 16326,
                    'num_classes': 3,
                    'language': 'en',
                    'KeyEval': 'Loss',  # Loss(pred_m)
                    # 'missing_rate': (0.1, 0.1, 0.1),
                    'missing_seed': (111, 1111, 11111),
                }
            },

            'asr_xf_mosei': {
                'unaligned': {
                    'dataPath': os.path.join(root_dataset_dir, 'MOSI/Processed/asr_xf_unaligned_mosei_50.pkl'),
                    'seq_lens': (50, 500, 375),
                    # (text, audio, video)
                    'feature_dims': (768, 74, 35),
                    'train_samples': 16326,
                    'num_classes': 3,
                    'language': 'en',
                    'KeyEval': 'Loss',  # Loss(pred_m)
                    # 'missing_rate': (0.1, 0.1, 0.1),
                    'missing_seed': (111, 1111, 11111),
                }
            },
        }
        return tmp
    def __MyASRmodel_post_bert(self):
        tmp = {
            'commonParas':{
                'data_missing': True,
                'deal_missing': False,
                'need_data_aligned': False,
                'need_model_aligned': False,
                'need_normalized': False,
                'use_bert': True,
                'use_finetune': True,
                'save_labels': False,
                'early_stop': 8,#8
                'update_epochs': 4
            },
            # dataset
            'datasetParas':{
                'mosi':{
                    # the batch_size of each epoch is update_epochs * batch_size
                    'batch_size': 32,
                    'learning_rate_bert': 5e-5,
                    'learning_rate_audio': 1e-3,
                    'learning_rate_video': 1e-4,
                    'learning_rate_other': 1e-3,
                    'weight_decay_bert': 0.001,
                    'weight_decay_audio': 0.01,
                    'weight_decay_video': 0.001,
                    'weight_decay_other': 0.001,
                    #CIR models
                    "ninp_v": 20,
                    "ninp_a": 5,
                    "nhead_v": 5,
                    "nhead_a": 1,
                    "nhid_v": 64,
                    "nhid_a": 32,
                    "nlayers": 3,
                    "ch_a": 1,
                    "sh_a": 1,
                    "ch_v": 5,
                    "sh_v": 5,
                    "ch": 8,
                    "sh": 8,
                    "dropout": 0.1,

                    "t_dim": 128,
                    "v_dim": 128,
                    "a_dim": 128,
                    "d_prjh": 128,
                    #"d_prjh1": 128,
                    "dropout_prj": 0.1,

                    "lengths": 49,
                    'd': 128,
                    'text_out': 768,
                    'audio_out': 5,
                    'video_out': 20,
                    'd_model': 128,
                    #CIR trains
                    "k": 0.5, #0.5
                    "beta": 1e-3,
                    "lamda": 2,#1.4 111,1111,11111  (32,0.4)
                    'temperature_F': 0.3,#0.3
                    'temperature_C': 0.3,#0.3
                    "t_w" : 0.4,#0.4
                    # "temperature": 1,#2 0.75 2.75
                    "omega1": 1,  #
                    "omega2": 0.01, # F
                    "omega3": 0.01 # C

                },
                'mosei': {
                    # the batch_size of each epoch is update_epochs * batch_size
                    'batch_size': 64,
                    'learning_rate_bert': 2e-5,  # 2
                    'learning_rate_audio': 1e-4,
                    'learning_rate_video': 1e-4,
                    'learning_rate_other': 1e-4,  # 1e-4
                    'weight_decay_bert': 1e-4,
                    'weight_decay_audio': 1e-4,
                    'weight_decay_video': 1e-4,
                    'weight_decay_other': 1e-4,
                    # CIR models
                    "ninp_v": 35,
                    "ninp_a": 74,
                    "nhead_v": 5,
                    "nhead_a": 1,
                    "nhid_v": 32,
                    "nhid_a": 32,
                    "nlayers": 3,
                    "ch_a": 1,
                    "sh_a": 1,
                    "ch_v": 5,
                    "sh_v": 5,
                    "ch": 8,
                    "sh": 8,
                    "dropout": 0.1,

                    "t_dim": 128,
                    "v_dim": 128,
                    "a_dim": 128,
                    "d_prjh": 128,
                    # "d_prjh1": 128,
                    "dropout_prj": 0.1,

                    "lengths": 49,
                    'd': 128,
                    'text_out': 768,
                    'audio_out': 74,
                    'video_out': 35,
                    'd_model': 128,
                    # CIR trains
                    "k": 0.5,  # 0.5
                    "beta": 1e-3,
                    "lamda": 2,  # 1.4 111,1111,11111  (32,0.4)
                    'temperature_F': 1,  # 1
                    'temperature_C': 1,  # 1
                    "t_w": 0.4,  # 0.4
                    # "temperature": 1,#2 0.75 2.75
                    "omega1": 1,  #
                    "omega2": 0.01,  # F
                    "omega3": 0.01  # C

                },
                'asr_speechbrain_mosei': {
                    # the batch_size of each epoch is update_epochs * batch_size
                    'batch_size': 64,
                    'learning_rate_bert': 2e-5,  # 2
                    'learning_rate_audio': 1e-4,
                    'learning_rate_video': 1e-4,
                    'learning_rate_other': 1e-4,  # 1e-4
                    'weight_decay_bert': 1e-4,
                    'weight_decay_audio': 1e-4,
                    'weight_decay_video': 1e-4,
                    'weight_decay_other': 1e-4,
                    # CIR models
                    "ninp_v": 35,
                    "ninp_a": 74,
                    "nhead_v": 5,
                    "nhead_a": 1,
                    "nhid_v": 32,
                    "nhid_a": 32,
                    "nlayers": 3,
                    "ch_a": 1,
                    "sh_a": 1,
                    "ch_v": 5,
                    "sh_v": 5,
                    "ch": 8,
                    "sh": 8,
                    "dropout": 0.1,

                    "t_dim": 128,
                    "v_dim": 128,
                    "a_dim": 128,
                    "d_prjh": 128,
                    # "d_prjh1": 128,
                    "dropout_prj": 0.1,

                    "lengths": 49,
                    'd': 128,
                    'text_out': 768,
                    'audio_out': 74,
                    'video_out': 35,
                    'd_model': 128,
                    # CIR trains
                    "k": 0.5,  # 0.5
                    "beta": 1e-3,
                    "lamda": 2,  # 1.4 111,1111,11111  (32,0.4)
                    'temperature_F': 1,  # 1
                    'temperature_C': 1,  # 1
                    "t_w": 0.4,  # 0.4
                    # "temperature": 1,#2 0.75 2.75
                    "omega1": 0.5,  #
                    "omega2": 0.1,  # F
                    "omega3": 0.1  # C

                },
                'asr_speechbrain_mosi': {
                    # the batch_size of each epoch is update_epochs * batch_size
                    'batch_size': 32,
                    'learning_rate_bert': 5e-5,
                    'learning_rate_audio': 1e-3,
                    'learning_rate_video': 1e-4,
                    'learning_rate_other': 1e-3,
                    'weight_decay_bert': 0.001,
                    'weight_decay_audio': 0.01,
                    'weight_decay_video': 0.001,
                    'weight_decay_other': 0.001,
                    # CIR models
                    "ninp_v": 20,
                    "ninp_a": 5,
                    "nhead_v": 5,
                    "nhead_a": 1,
                    "nhid_v": 64,
                    "nhid_a": 64,
                    "nlayers": 3,
                    "ch_a": 1,
                    "sh_a": 1,
                    "ch_v": 5,
                    "sh_v": 5,
                    "ch": 8,
                    "sh": 8,
                    "dropout": 0.1,

                    "t_dim": 128,
                    "v_dim": 128,
                    "a_dim": 128,
                    "d_prjh": 128,
                    # "d_prjh1": 128,
                    "dropout_prj": 0.1,

                    "lengths": 49,
                    'd': 128,
                    'text_out': 768,
                    'audio_out': 5,
                    'video_out': 20,
                    'd_model': 128,
                    # CIR trains
                    "beta": 1e-3,
                    "k": 0.4,
                    "lamda": 2,  # 2
                    'temperature_F': 0.8, #0.8 bert-pre 0.4 bert   #0.2 0.4 0.8
                    'temperature_C': 0.8, #0.8 bert-pre 0.4 bert    #2 1.2
                    "t_w": 0.4,#2 3 #0.4 bert-pre 0.4 bert
                    # "temperature": 1,#2 0.75 2.75
                    "omega1": 0.5,  #
                    "omega2": 0.1,  #0.1
                    "omega3": 0.1  #0.1

                },
                'asr_ibm_mosei': {
                    # the batch_size of each epoch is update_epochs * batch_size
                    'batch_size': 64,
                    'learning_rate_bert': 2e-5,  # 2
                    'learning_rate_audio': 1e-4,
                    'learning_rate_video': 1e-4,
                    'learning_rate_other': 1e-4,  # 1e-4
                    'weight_decay_bert': 1e-4,
                    'weight_decay_audio': 1e-4,
                    'weight_decay_video': 1e-4,
                    'weight_decay_other': 1e-4,
                    # CIR models
                    "ninp_v": 35,
                    "ninp_a": 74,
                    "nhead_v": 5,
                    "nhead_a": 1,
                    "nhid_v": 32,
                    "nhid_a": 32,
                    "nlayers": 3,
                    "ch_a": 1,
                    "sh_a": 1,
                    "ch_v": 5,
                    "sh_v": 5,
                    "ch": 8,
                    "sh": 8,
                    "dropout": 0.1,

                    "t_dim": 128,
                    "v_dim": 128,
                    "a_dim": 128,
                    "d_prjh": 128,
                    # "d_prjh1": 128,
                    "dropout_prj": 0.1,

                    "lengths": 49,
                    'd': 128,
                    'text_out': 768,
                    'audio_out': 74,
                    'video_out': 35,
                    'd_model': 128,
                    # CIR trains
                    "k": 0.4,  # 0.5
                    "beta": 1e-3,
                    "lamda": 2,  # 1.4 111,1111,11111  (32,0.4)
                    'temperature_F': 0.4,  # 1
                    'temperature_C': 0.4,  # 1
                    "t_w": 0.2,  # 0.4
                    # "temperature": 1,#2 0.75 2.75
                    "omega1": 0.5,  #
                    "omega2": 0.1,  # F
                    "omega3": 0.1  # C

                },
                'asr_ibm_mosi': {
                    # the batch_size of each epoch is update_epochs * batch_size
                    'batch_size': 32,
                    'learning_rate_bert': 5e-5,
                    'learning_rate_audio': 1e-3,
                    'learning_rate_video': 1e-4,
                    'learning_rate_other': 1e-3,
                    'weight_decay_bert': 0.001,
                    'weight_decay_audio': 0.01,
                    'weight_decay_video': 0.001,
                    'weight_decay_other': 0.001,
                    # CIR models
                    "ninp_v": 20,
                    "ninp_a": 5,
                    "nhead_v": 5,
                    "nhead_a": 1,
                    "nhid_v": 64,
                    "nhid_a": 32,
                    "nlayers": 3,
                    "ch_a": 1,
                    "sh_a": 1,
                    "ch_v": 5,
                    "sh_v": 5,
                    "ch": 8,
                    "sh": 8,
                    "dropout": 0.1,

                    "t_dim": 128,
                    "v_dim": 128,
                    "a_dim": 128,
                    "d_prjh": 128,
                    # "d_prjh1": 128,
                    "dropout_prj": 0.1,

                    "lengths": 49,
                    'd': 128,
                    'text_out': 768,
                    'audio_out': 5,
                    'video_out': 20,
                    'd_model': 128,
                    # CIR trains
                    "beta": 1e-3,
                    "k": 0.4,#0.4 bert-pre
                    "lamda": 2,  # 1.4 111,1111,11111  (32,0.4)
                    'temperature_F': 0.8,#0.8 bert-pre 0.4 bert
                    'temperature_C': 0.8,#0.8 bert-pre 0.4 bert
                    "t_w": 0.2,#0.2 bert-pre#0.3
                    # "temperature": 1,#2 0.75 2.75
                    "omega1": 0.5,  #
                    "omega2": 0.1,  #
                    "omega3": 0.1  #

                },
                'asr_xf_mosei': {
                    # the batch_size of each epoch is update_epochs * batch_size
                    'batch_size': 64,
                    'learning_rate_bert': 2e-5,  # 2
                    'learning_rate_audio': 1e-4,
                    'learning_rate_video': 1e-4,
                    'learning_rate_other': 1e-4,  # 1e-4
                    'weight_decay_bert': 1e-4,
                    'weight_decay_audio': 1e-4,
                    'weight_decay_video': 1e-4,
                    'weight_decay_other': 1e-4,
                    # CIR models
                    "ninp_v": 35,
                    "ninp_a": 74,
                    "nhead_v": 5,
                    "nhead_a": 1,
                    "nhid_v": 32,
                    "nhid_a": 32,
                    "nlayers": 3,
                    "ch_a": 1,
                    "sh_a": 1,
                    "ch_v": 5,
                    "sh_v": 5,
                    "ch": 8,
                    "sh": 8,
                    "dropout": 0.1,

                    "t_dim": 128,
                    "v_dim": 128,
                    "a_dim": 128,
                    "d_prjh": 128,
                    # "d_prjh1": 128,
                    "dropout_prj": 0.1,

                    "lengths": 49,
                    'd': 128,
                    'text_out': 768,
                    'audio_out': 74,
                    'video_out': 35,
                    'd_model': 128,
                    # CIR trains
                    "beta": 1e-3,
                    "lamda": 2,  # 2
                    "k": 0.4,
                    'temperature_F': 0.8,  # xing 0.2 0.07
                    'temperature_C': 0.8,  # 0.2
                    "t_w": 0.5,  # 2
                    "omega1": 1,  # 0.5
                    "omega2": 0.05,  # 0.01
                    "omega3": 0.05  # 0.01

                },
                'asr_xf_mosi': {
                    # the batch_size of each epoch is update_epochs * batch_size
                    'batch_size': 32,
                    'learning_rate_bert': 5e-5,
                    'learning_rate_audio': 1e-3,
                    'learning_rate_video': 1e-4,
                    'learning_rate_other': 1e-3,
                    'weight_decay_bert': 0.001,
                    'weight_decay_audio': 0.01,
                    'weight_decay_video': 0.001,
                    'weight_decay_other': 0.001,
                    # CIR models
                    "ninp_v": 20,
                    "ninp_a": 5,
                    "nhead_v": 5,
                    "nhead_a": 1,
                    "nhid_v": 64,
                    "nhid_a": 32,
                    "nlayers": 3,
                    "ch_a": 1,
                    "sh_a": 1,
                    "ch_v": 5,
                    "sh_v": 5,
                    "ch": 8,
                    "sh": 8,
                    "dropout": 0.1,

                    "t_dim": 128,
                    "v_dim": 128,
                    "a_dim": 128,
                    "d_prjh": 128,
                    # "d_prjh1": 128,
                    "dropout_prj": 0.1,

                    "lengths": 49,
                    'd': 128,
                    'text_out': 768,
                    'audio_out': 5,
                    'video_out': 20,
                    'd_model': 128,
                    # CIR trains
                    "beta": 1e-3,
                    "lamda": 2,  # 2
                    "k": 0.4,
                    'temperature_F': 0.8, #xing 0.2 0.07
                    'temperature_C': 0.8, #0.2
                    "t_w": 0.5, #2
                    "omega1": 1,  # 0.5
                    "omega2": 0.05,  #0.05
                    "omega3": 0.05  #0.01

                },
                'con_sims': {
                    # the batch_size of each epoch is update_epochs * batch_size
                    'batch_size': 32,
                    'learning_rate_bert': 2e-5,  # 2e-5
                    'learning_rate_audio': 1e-3,  # 1e-3
                    'learning_rate_video': 1e-3,
                    'learning_rate_other': 1e-3,
                    'weight_decay_bert': 0.001,
                    'weight_decay_audio': 0,
                    'weight_decay_video': 0,
                    'weight_decay_other': 0,

                    # 'batch_size': 32,
                    # 'learning_rate_bert': 5e-5,
                    # 'learning_rate_audio': 5e-4,
                    # 'learning_rate_video': 5e-4,
                    # 'learning_rate_other': 5e-4,
                    # 'weight_decay_bert': 0.001,
                    # 'weight_decay_audio': 0.01,
                    # 'weight_decay_video': 0.01,
                    # 'weight_decay_other': 0.001,

                    # CIR models
                    "ninp_v": 709,
                    # "ninp_v1": 709,
                    "ninp_a": 33,
                    "nhead_v": 1,
                    "nhead_a": 3,
                    "nhid_v": 64,
                    "nhid_a": 32,
                    "nlayers": 3,

                    "ch_a": 3,
                    "sh_a": 3,
                    "ch_v": 1,
                    "sh_v": 1,

                    "ch": 4,
                    "sh": 4,
                    "dropout": 0.1,

                    "t_dim": 64,
                    "v_dim": 64,
                    "a_dim": 64,
                    "d_prjh": 64,
                    # "d_prjh1": 64,
                    "dropout_prj": 0.1,

                    "lengths": 38,
                    'd': 64,
                    'text_out': 768,
                    'audio_out': 33,
                    'video_out': 709,
                    'd_model': 64,
                    # CIR trains
                    "k": 0.1,  # 0.3
                    "beta": 1e-3,
                    "lamda": 2,
                    'temperature_F': 0.5,
                    'temperature_C': 0.5,
                    "t_w": 1.2,  # 0.6
                    "omega1": 1,  #
                    "omega2": 0.1,  #
                    "omega3": 0.1  #
                },

            },
        }
        return tmp

    def get_config(self):
        return self.args