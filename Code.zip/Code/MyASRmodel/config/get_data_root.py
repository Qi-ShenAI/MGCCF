# set your dataset path

# data_root = '/root/autodl-tmp/EMT-DLFR-master/EMT-DLFR-master/' # e.g., mine: '/data/ycs/AC/Dataset/MMSA'
# data_root1 = '/root/autodl-tmp/EMT-DLFR-master/EMT-DLFR-master/' # e.g., mine: '/data/ycs/AC/Dataset/MMSA'
data_root = 'E:/MyASRmodel/' # e.g., mine: '/data/ycs/AC/Dataset/MMSA'
data_root1 = 'E:/MyASRmodel/' # e.g., mine: '/data/ycs/AC/Dataset/MMSA'