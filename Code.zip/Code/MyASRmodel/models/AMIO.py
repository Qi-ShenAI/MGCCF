"""
AIO -- All Model in One
"""
import torch.nn as nn

from models.singleTask import *
from models.multiTask import *
from models.subNets import AlignSubNet
__all__ = ['AMIO']

MODEL_MAP = {
    # single-task
    'cirp': CIRP,
    'myasrmodel_post_bert': MyASRmodel_post_bert,
    'mymodel_post_bert': Mymodel_post_bert,
    'myasrmodel': MyASRmodel,
    'mymodel': Mymodel,
    'swrm': SWRM,
    'swrmbase': SWRMbase,
    'mult': MULT,
    'misa': MISA,
    'self_mm': SELF_MM,
    'emt_dlfr': EMT_DLFR,
    'myasrmodel_post_bert_wo_cucl': MyASRmodel_post_bert_Wo_CUCL,
    'myasrmodel_post_bert_wo_ftcl': MyASRmodel_post_bert_Wo_FTCL,
    'myasrmodel_post_bert_wo_ib': MyASRmodel_post_bert_Wo_IB,
    'myasrmodel_post_bert_wo_gci': MyASRmodel_post_bert_Wo_GCI,
    'myasrmodel_post_bert_wo_micf': MyASRmodel_post_bert_Wo_MICF,
    'mymodel_wo_cucl': Mymodel_Wo_CUCL,
    'mymodel_wo_ftcl': Mymodel_Wo_FTCL,
    'mymodel_wo_ib': Mymodel_Wo_IB,
    'mymodel_wo_gci': Mymodel_Wo_GCI,
    'mymodel_wo_micf': Mymodel_Wo_MICF,
}
class AMIO(nn.Module):
    def __init__(self, args):
        super(AMIO, self).__init__()
        # simulating word-align network (for seq_len_T == seq_len_A == seq_len_V)
        self.need_model_aligned = args.get('need_model_aligned', None)
        # simulating word-align network (for seq_len_T == seq_len_A == seq_len_V)
        if (self.need_model_aligned):
            self.alignNet = AlignSubNet(args, 'avg_pool')
            if 'seq_lens' in args.keys():
                args['seq_lens'] = self.alignNet.get_seq_len()
        lastModel = MODEL_MAP[args.modelName]
        self.Model = lastModel(args)

    def forward(self, text_x, audio_x, video_x, *args, **kwargs):
        # audio_x, audio_lengths = audio_x
        # # print(audio_lengths)
        # video_x, video_lengths = video_x


        # if (self.need_model_aligned):
        #     text_x, audio_x, video_x = self.alignNet(text_x, audio_x, video_x)

        return self.Model(text_x, audio_x, video_x, *args, **kwargs)
