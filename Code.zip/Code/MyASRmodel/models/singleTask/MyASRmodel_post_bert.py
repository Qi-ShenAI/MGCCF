import os
import sys
import collections
import time

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils.rnn import pad_sequence, pack_padded_sequence, pad_packed_sequence
from torch.autograd import Function
from models.subNets.BertTextEncoder import BertTextEncoder
from models.subNets.BertSelfTokenEncoder_post import BertSelfTokenEncoder
from models.singleTask.encoders import *
from models.subNets import AlignSubNet
from transformers import BertModel, BertConfig
import warnings

warnings.filterwarnings("ignore", message="enable_nested_tensor is True, but self.use_nested_tensor is False")


__all__ = ['CIR']
beta  = 1e-3
class MyASRmodel_post_bert(nn.Module):  # 未缺失情况 最好的
    def __init__(self, args):
        super().__init__()
        # self.name = args.datasetName
        self.k = args.k
        self.aligned = args.need_data_aligned
        #self.detection_text_model = BertTextEncoder(language=args.language, use_finetune=args.use_finetune)
        self.text_model = BertSelfTokenEncoder(language=args.language, use_finetune=args.use_finetune)
        # self.video_model = TransformerEncoder(ninp=128, nhead=4, nhid=64, nlayers=3, dropout=0.1)
        # self.audio_model = TransformerEncoder(ninp=128, nhead=4, nhid=64, nlayers=3, dropout=0.1)
        self.video_model = TransformerEncoder(ninp=args.ninp_v, nhead=args.nhead_v, nhid=args.nhid_v,
                                              nlayers=args.nlayers, dropout=args.dropout)
        self.audio_model = TransformerEncoder(ninp=args.ninp_a, nhead=args.nhead_a, nhid=args.nhid_a,
                                              nlayers=args.nlayers, dropout=args.dropout)
        self.gate_linear = nn.Linear(args.text_out * 2, 1)
        self.fusion_gate_linear = nn.Linear(args.t_dim * 2, args.t_dim)

        self.pa_encoder = BimodalFusionLayer(embed_dim=args.a_dim, cross_heads=args.ch, self_heads=args.sh, # BBimodalFusionLayer
                                              kdim=args.a_dim,
                                              vdim=args.a_dim)
        self.pv_encoder = BimodalFusionLayer(embed_dim=args.v_dim, cross_heads=args.ch, self_heads=args.sh,
                                              kdim=args.v_dim,
                                              vdim=args.v_dim)

        self.encoder_a = nn.Sequential(nn.Linear(args.a_dim, args.d),
                                       #  nn.ReLU(inplace=True),
                                       # nn.Linear(1024, 1024),
                                       nn.ReLU(inplace=True))
        self.encoder_v = nn.Sequential(nn.Linear(args.v_dim, args.d),
                                       #  nn.ReLU(inplace=True),
                                       # nn.Linear(1024, 1024),
                                       nn.ReLU(inplace=True))

        self.fc_mu_a = nn.Linear(args.d, args.a_dim)
        self.fc_std_a = nn.Linear(args.d, args.a_dim)

        self.fc_mu_v = nn.Linear(args.d, args.v_dim)
        self.fc_std_v = nn.Linear(args.d, args.v_dim)

        self.decoder_a = nn.Linear(args.a_dim, 1)
        self.decoder_v = nn.Linear(args.v_dim, 1)

        self.FC_CCL_T = Pro_C(
            in_size=args.t_dim,
            hidden_size=args.d_prjh,
            dropout=args.dropout_prj
        )
        self.FC_CCL_A = Pro_C(
            in_size=args.a_dim,
            hidden_size=args.d_prjh,
            dropout=args.dropout_prj
        )
        self.FC_CCL_V = Pro_C(
            in_size=args.v_dim,
            hidden_size=args.d_prjh,
            dropout=args.dropout_prj
        )

        self.FC_FCL_T = Pro_F(
            in_size=args.t_dim,
            hidden_size1=args.lengths,
            hidden_size2=args.d_prjh,
            dropout=args.dropout_prj
        )
        self.FC_FCL_A = Pro_F(
            in_size=args.a_dim,
            hidden_size1=args.lengths,
            hidden_size2=args.d_prjh,
            dropout=args.dropout_prj
        )
        self.FC_FCL_V = Pro_F(
            in_size=args.v_dim,
            hidden_size1=args.lengths,
            hidden_size2=args.d_prjh,
            dropout=args.dropout_prj
        )

        #  2. bimodal fusion
        self.att_encoder = AttenLayer(embed_dim=args.t_dim, cross_heads=args.ch, self_heads=args.sh, kdim=args.t_dim,
                                      vdim=args.t_dim)

        # self.vt_encoder = BimodalFusionLayer(embed_dim=args.v_dim, cross_heads=args.ch, self_heads=args.sh,
        #                                      kdim=args.v_dim,
        #                                      vdim=args.v_dim)
        # self.at_encoder = BimodalFusionLayer(embed_dim=args.a_dim, cross_heads=args.ch, self_heads=args.sh,
        #                                      kdim=args.a_dim,
        #                                      vdim=args.a_dim)
        self.tv_encoder = BimodalFusionLayer(embed_dim=args.v_dim, cross_heads=args.ch, self_heads=args.sh,
                                             kdim=args.v_dim,
                                             vdim=args.v_dim)
        self.ta_encoder = BimodalFusionLayer(embed_dim=args.a_dim, cross_heads=args.ch, self_heads=args.sh,
                                             kdim=args.a_dim,
                                             vdim=args.a_dim)
        # self.attn_pool = NaiveAttention(args.time_length * args.t_dim, activation_fn='tanh')
        #self.GRL = GradientReversalLayer(alpha=1.0)
        # 3. last fusion

        self.fusion_prj = MLP(
            in_size=args.d_prjh,
            hidden_size=args.d_prjh,  # 128
            n_class=1,
            dropout=args.dropout_prj
        )

        # self.Pru = TransformerEncoder(ninp=128, nhead=4, nhid=128, nlayers=2, dropout=0.1)
        # self.proj_v= nn.Linear(args.video_out, args.ninp_v,
        #                             bias=False) if args.datasetName == 'sims' else nn.Identity()

        self.proj_audio = nn.Linear(args.audio_out, args.d_model,
                                    bias=False) if args.audio_out != args.d_model else nn.Identity()
        self.proj_video = nn.Linear(args.video_out, args.d_model,
                                    bias=False) if args.video_out != args.d_model else nn.Identity()
        self.proj_text = nn.Linear(args.text_out, args.d_model,
                                   bias=False) if args.text_out != args.d_model else nn.Identity()
        self.proj_text_update = nn.Linear(args.text_out, args.d_model,
                                    bias=False) if args.text_out != args.d_model else nn.Identity()

        self.using_cuda = len(args.gpu_ids) > 0 and torch.cuda.is_available()
        self.device = torch.device('cuda:%d' % int(args.gpu_ids[0]) if self.using_cuda else 'cpu')

    def encode_a(self, x):
        """
        x : [batch_size,784]
        """
        x = self.encoder_a(x)
        return self.fc_mu_a(x), F.softplus(self.fc_std_a(x) - 5, beta=1)

    def encode_v(self, x):
        """
        x : [batch_size,784]
        """
        x = self.encoder_v(x)
        return self.fc_mu_v(x), F.softplus(self.fc_std_v(x) - 5, beta=1)

    def decode_a(self, z):
        return self.decoder_a(z)

    def decode_v(self, z):
        return self.decoder_v(z)

    def reparameterise(self, mu, std):
        """
        mu : [batch_size,z_dim]
        std : [batch_size,z_dim]
        """
        # get epsilon from standard normal
        eps = torch.randn_like(std)
        return mu + std * eps

    def forward(self, text, audio, video):
        audio, audio_lengths = audio
        video, video_lengths = video
        mask_len = torch.sum(text[:, 1, :], dim=1, keepdim=True)
        text_lengths = mask_len.squeeze().int().detach() - 2  # -2 for CLS and SEP
        input_ids, input_mask, segment_ids = text[:, 0, :].long(), text[:, 1, :].float(), text[:, 2, :].long()

        text_embeddings = self.text_model(text, text, order="first")

        cls_a = nn.Parameter(torch.randn(1, 1, audio.shape[-1])).to(self.device)
        cls_v = nn.Parameter(0.2 * torch.randn(1, 1, video.shape[-1])).to(self.device)
        cls_a_ = cls_a.repeat(audio.shape[0], 1, 1)
        cls_v_ = cls_v.repeat(video.shape[0], 1, 1)
        acoustic = torch.cat([cls_a_, audio], dim=1)
        visual = torch.cat([cls_v_, video], dim=1)

        mask_t = ~input_mask.bool()
        # print(mask_t[3])
        # exit()
        # visual = self.proj_v(visual)

        max_audio_lengths_length = audio_lengths.max().item()
        max_video_lengths_length = video_lengths.max().item()
        mask_a = self.audio_model.generate_square_subsequent_mask(acoustic, audio_lengths + 1).to(self.device)
        mask_v = self.video_model.generate_square_subsequent_mask(visual, video_lengths + 1).to(self.device)
        acoustic = self.audio_model(acoustic[:, :max_audio_lengths_length + 1], mask_a)  # length, batch_size, dim
        visual = self.video_model(visual[:, :max_video_lengths_length + 1], mask_v)  # length, batch_size, dim
        text_embeddings_d, acoustic, visual = self.proj_text(text_embeddings), self.proj_audio(acoustic), self.proj_video(visual)  # d相同了

        pur_acoustic = nn.Parameter(torch.randn(1, text_embeddings.shape[-2] - 1, acoustic.shape[-1])).to(self.device)
        pur_visual = nn.Parameter(0.2 * torch.randn(1, text_embeddings.shape[-2] - 1, visual.shape[-1])).to(self.device)

        pur_acoustic_ = pur_acoustic.repeat(acoustic.shape[0], 1, 1)
        pur_visual_ = pur_visual.repeat(visual.shape[0], 1, 1)

        utterance_acoustic_visual = torch.cat([acoustic[:, 0, :].unsqueeze(1), visual[:, 0, :].unsqueeze(1)], dim=1)

        _, atten = self.att_encoder(x=text_embeddings_d, x_k=utterance_acoustic_visual, x_v=utterance_acoustic_visual, key_padding_mask=None, attn_mask=None)


        atten = atten.mean(dim=2)[:,]


        min_indices = []
        for i in range(atten.shape[0]):
            # 对于第i行，找到前 text_lengths[i] 个有效值中的最小值的位置
            valid_part = atten[i, 1 : text_lengths[i] + 1]  # 获取有效部分

            min_index = valid_part.argmin() + 1  # 找到最小值的位置

            min_indices.append(min_index)  # 存储位置
        embedding_masks = torch.zeros(atten.shape[0], atten.shape[1])
        embedding_masks[torch.arange(atten.shape[0]), min_indices] = 1
        embedding_masks = embedding_masks.cuda()

        embedding_map = self.text_model.get_input_embeddings()
        mask_id = torch.LongTensor([103]).cuda()  # mask embedding
        mask_embedding = embedding_map(mask_id)
        mask_embedding = mask_embedding.unsqueeze(0).expand_as(text_embeddings)
        added_gate_input = torch.cat([text_embeddings, mask_embedding], -1)
        added_gate_value = torch.sigmoid(self.gate_linear(added_gate_input)) * embedding_masks.unsqueeze(2)


        gate_text_embeddings = (1 - added_gate_value) * text_embeddings + added_gate_value * mask_embedding

        pur_acoustic_ = self.pa_encoder(x=pur_acoustic_, x_k=acoustic[:, 1:], x_v=acoustic[:, 1:],
                                        key_padding_mask=mask_a[:, 1:], attn_mask=None)
        pur_visual_ = self.pv_encoder(x=pur_visual_, x_k=visual[:, 1:], x_v=visual[:, 1:],
                                      key_padding_mask=mask_v[:, 1:], attn_mask=None)

        acoustic_weights = torch.softmax(pur_acoustic_, dim=1)
        pur_acoustic_avg = torch.sum(acoustic_weights * pur_acoustic_, dim=1)
        visual_weights = torch.softmax(pur_visual_, dim=1)
        pur_visual_avg = torch.sum(visual_weights * pur_visual_, dim=1)


        # Information Bottleneck
        mu_a, std_a = self.encode_a(pur_acoustic_avg)
        z_a = self.reparameterise(mu_a, std_a)

        output_a = self.decode_a(z_a)

        mu_v, std_v = self.encode_v(pur_visual_avg)
        z_v = self.reparameterise(mu_v, std_v)
        output_v = self.decode_v(z_v)

        # gate_text_embeddings yizhixing
        update_text_embeddings = self.text_model(text, gate_text_embeddings, order="second")
        update_text_embeddings = self.proj_text_update(update_text_embeddings)

        # Coarse-grained contrastive learning
        z_CCL_T = self.FC_CCL_T(update_text_embeddings[:, 0, :])
        z_CCL_A = self.FC_CCL_A(acoustic[:, 0, :])
        z_CCL_V = self.FC_CCL_V(visual[:, 0, :])

        # Fine-grained contrastive learning
        z_FCL_T = self.FC_FCL_T(update_text_embeddings[:, 1:, :])
        z_FCL_A = self.FC_FCL_A(pur_acoustic_)
        z_FCL_V = self.FC_FCL_V(pur_visual_)

        ##################cross modal
        weight_acoustic = torch.sigmoid(acoustic) * acoustic
        weight_visual = torch.sigmoid(visual) * visual
        acoustic_based_text = self.ta_encoder(x=update_text_embeddings, x_k=weight_acoustic, x_v=weight_acoustic,
                                              key_padding_mask=mask_a, attn_mask=None)
        visual_based_text = self.tv_encoder(x=update_text_embeddings, x_k=weight_visual, x_v=weight_visual, key_padding_mask=mask_v,
                                            attn_mask=None)
        # text_based_acoustic = self.at_encoder(x=acoustic, x_k=update_text_embeddings, x_v=update_text_embeddings,
        #                                       key_padding_mask=mask_t, attn_mask=None)
        # text_based_visual = self.vt_encoder(x=visual, x_k=update_text_embeddings, x_v=update_text_embeddings,
        #                                     key_padding_mask=mask_t, attn_mask=None)



        r_ta = acoustic_based_text[:, 0, :]
        r_tv = visual_based_text[:, 0, :]
        r_a = acoustic[:, 0, :]
        r_v = visual[:, 0, :]
        r_tav = torch.cat([r_ta, r_tv], -1)
        fusion_gate_value = torch.sigmoid(self.fusion_gate_linear(r_tav ))
        r_fusion_t = fusion_gate_value * r_ta + (1 - fusion_gate_value) * r_tv
        p_r_fusion_t = F.softmax(r_fusion_t, dim=-1)
        p_r_a = F.softmax(r_a, dim=-1)
        p_r_v = F.softmax(r_v, dim=-1)

        # entropy_r_fusion_t = torch.exp(-self.k * (-(p_r_fusion_t * torch.log(p_r_fusion_t)).sum(dim=-1)))
        # entropy_r_a = torch.exp(-self.k * (-(p_r_a * torch.log(p_r_a)).sum(dim=-1)))
        # entropy_r_v = torch.exp(-self.k * (-(p_r_v * torch.log(p_r_v)).sum(dim=-1)))
        entropy_r_fusion_t = torch.sigmoid(-self.k * (-(p_r_fusion_t * torch.log(p_r_fusion_t)).sum(dim=-1)))
        entropy_r_a = torch.sigmoid(-self.k * (-(p_r_a * torch.log(p_r_a)).sum(dim=-1)))
        entropy_r_v = torch.sigmoid(-self.k * (-(p_r_v * torch.log(p_r_v)).sum(dim=-1)))
        #print(entropy_r_fusion_t, entropy_r_a, entropy_r_v)
        # exit()


        # entropy_r_fusion_t = 1 / (-(-(p_r_fusion_t * torch.log(p_r_fusion_t)).sum(dim=-1)))
        # entropy_r_a = 1 / (-(-(p_r_a * torch.log(p_r_a)).sum(dim=-1)))
        # entropy_r_v = 1 / (-(-(p_r_v * torch.log(p_r_v)).sum(dim=-1)))


        weight_t = entropy_r_fusion_t / (entropy_r_fusion_t + entropy_r_a + entropy_r_v)
        weight_a = entropy_r_a / (entropy_r_fusion_t + entropy_r_a + entropy_r_v )
        weight_v = entropy_r_v / (entropy_r_fusion_t + entropy_r_a + entropy_r_v)


        fusion_representation = weight_t.unsqueeze(1) * r_fusion_t + weight_a.unsqueeze(1) * r_a + weight_v.unsqueeze(1) * r_v
        #fusion_representation = r_fusion_t + r_a + r_v
        preds = self.fusion_prj(fusion_representation)

        res = {
            f'pred': preds,
            f'mu_a': mu_a,
            f'std_a': std_a,
            f'output_a': output_a,
            f'mu_v': mu_v,
            f'std_v': std_v,
            f'output_v': output_v,
            f'z_CCL_T': z_CCL_T,
            f'z_CCL_A': z_CCL_A,
            f'z_CCL_V': z_CCL_V,
            f'z_FCL_T': z_FCL_T,
            f'z_FCL_A': z_FCL_A,
            f'z_FCL_V': z_FCL_V,
            f'atten':atten

            # f'weight_t': weight_t,
            # f'weight_a': weight_a,
            # f'weight_v': weight_v,
            #f'representation': final_representation
        }

        return {**res}
def compute_joint(view1, view2):
    """Compute the joint probability matrix P"""

    bn, k = view1.size()
    assert (view2.size(0) == bn and view2.size(1) == k)

    p_i_j = view1.unsqueeze(2) * view2.unsqueeze(1)
    #p_i_j = p_i_j.sum(dim=0)
    p_i_j = (p_i_j + p_i_j.permute(0,2,1)) / 2.  # symmetrise
    # print(p_i_j.t().shape)
    # print(p_i_j.shape)
    p_i_j = p_i_j / p_i_j.sum()  # normalise

    return p_i_j
def Incongruity(view1, view2, lamb=0.0, EPS=sys.float_info.epsilon):
    """Contrastive loss for maximizng the consistency"""
    ε = 0.000001
    bn, k = view1.size()
    p_i_j = compute_joint(view1, view2)

    #print("p_i_j",p_i_j.shape)
    assert (p_i_j.size() == (bn, k, k))
    # print("p_i_j",p_i_j.shape)
    p_i = p_i_j.sum(dim=2).view(bn,k, 1).expand(bn,k, k)
    p_j = p_i_j.sum(dim=1).view(bn,1, k).expand(bn,k, k)
    #print(p_i.shape)

    # print("p_i", p_i.shape)
    # print("p_j", p_j.shape)
    #     Works with pytorch <= 1.2
    #     p_i_j[(p_i_j < EPS).data] = EPS
    #     p_j[(p_j < EPS).data] = EPS
    #     p_i[(p_i < EPS).data] = EPS

    # Works with pytorch > 1.2
    p_i_j = torch.where(p_i_j < EPS, torch.tensor([EPS], device=p_i_j.device), p_i_j)
    p_j = torch.where(p_j < EPS, torch.tensor([EPS], device=p_j.device), p_j)
    p_i = torch.where(p_i < EPS, torch.tensor([EPS], device=p_i.device), p_i)
    I_i_j = p_i_j * (torch.log(p_i_j) - (torch.log(p_i) + torch.log(p_j)))
    H_i_j = - p_i_j * torch.log(p_i_j)
    #acl_0 = I_i_j / (H_i_j + ε)
    acl_0 = I_i_j / (H_i_j)
    #print(I_i_j.shape)
    #print(H_i_j.shape)
    #print(acl_0.shape)


    acl_0 = torch.mean(acl_0[:,:,0], dim=1)
    #print(acl_0.shape)
    #exit()
    #print(acl_0.shape)
    # print(acl_0[0:1,0:8,0:8])
    # exit()

    # acl_1 = torch.mean(acl_0,dim=1)
    # acl_2 = torch.mean(acl_1, dim=1)
    #acl = (acl_1 + acl_2) / 2
    #print(acl)
    #print(acl.shape)


    return acl_0
class MI_Projector(nn.Module):
    def __init__(self, ecoder_dim1, ecoder_dim2):
        super(MI_Projector, self).__init__()
        self.fc = nn.Linear(ecoder_dim1, ecoder_dim2)
        self.BN = nn.BatchNorm1d(ecoder_dim2)
        self.relu = nn.ReLU()
        self.fc_1 = nn.Linear(ecoder_dim2, ecoder_dim2)
        self.Soft = nn.Softmax(dim=1)
    def forward(self, x):
        ##################
        x = self.fc(x)
        x = self.BN(x)
        x = self.fc_1(x)
        x = self.Soft(x)
        return x
class IncongruityLearning(nn.Module):
    def __init__(self, ecoder_dim1, ecoder_dim2):
        super(IncongruityLearning, self).__init__()
        # self.encoding = EncodingPart()
        self.MI_Projector1 = MI_Projector(ecoder_dim1, ecoder_dim2)
        self.MI_Projector2 = MI_Projector(ecoder_dim1, ecoder_dim2)
    def forward(self, x1_encoding, x2_encoding):
        x1_P = self.MI_Projector1(x1_encoding)
        x2_P = self.MI_Projector2(x2_encoding)
        skl = Incongruity(x1_P, x2_P)
        return skl


class ReverseLayerF(Function):

    @staticmethod
    def forward(ctx, x, alpha):
        ctx.alpha = alpha
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output):
        output = grad_output.neg() * ctx.alpha
        return output, None
class AuViSubNet(nn.Module):
    def __init__(self, in_size, hidden_size, out_size=None, num_layers=1, dropout=0.2, bidirectional=False):
        '''
        Args:
            in_size: input dimension
            hidden_size: hidden layer dimension
            num_layers: specify the number of layers of LSTMs.
            dropout: dropout probability
            bidirectional: specify usage of bidirectional LSTM
        Output:
            (return value in forward) a tensor of shape (batch_size, out_size)
        '''
        super().__init__()
        self.rnn = nn.LSTM(in_size, hidden_size, num_layers=num_layers, dropout=dropout, bidirectional=bidirectional, batch_first=True)
        self.dropout = nn.Dropout(dropout)
        feature_size = hidden_size * 2 if bidirectional else hidden_size
        self.linear_1 = nn.Linear(feature_size, out_size) if feature_size != out_size and out_size is not None else nn.Identity()

    def forward(self, x, lengths, return_temporal=False):
        '''
        x: (batch_size, sequence_len, in_size)
        '''
        # for pytorch1.2
        # packed_sequence = pack_padded_sequence(x, lengths, batch_first=True, enforce_sorted=False)
        # for pytorch1.7
        packed_sequence = pack_padded_sequence(x, lengths.cpu(), batch_first=True, enforce_sorted=False)
        packed_last_hidden_state, final_states = self.rnn(packed_sequence)



        h = self.dropout(final_states[0].squeeze())
        y_1 = self.linear_1(h)
        if not return_temporal:
            return y_1
        else:
            unpacked_last_hidden_state, _ = pad_packed_sequence(packed_last_hidden_state, batch_first=True)
            last_hidden_state = self.linear_1(unpacked_last_hidden_state)
            return last_hidden_state, y_1




class Projector(nn.Module):
    def __init__(self, input_dim, pred_dim, output_dim):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(input_dim, pred_dim), #, bias=False
                                 nn.BatchNorm1d(pred_dim),
                                 nn.ReLU(inplace=True),  # hidden layer
                                 nn.Linear(pred_dim, output_dim),#
                                 #nn.Tanh())
                                 nn.Sigmoid())  # output layer

    def forward(self, x):
        return self.net(x)


def _get_activation_fn(activation):
    if activation == "relu":
        return nn.ReLU
    elif activation == "sigmoid":
        return nn.Sigmoid
    elif activation == "tanh":
        return nn.Tanh
    else:
        raise NotImplementedError
class NaiveAttention(nn.Module):
    def __init__(self, dim, activation_fn='relu'):
        super().__init__()

        self.attention = nn.Sequential(
            nn.Linear(dim, dim),
            _get_activation_fn(activation_fn)(),
            nn.Linear(dim, 1)
        )

    def forward(self, inputs):
        """
        :param inputs: (B, T, D)
        :return: (B, D)
        """

        scores = self.attention(inputs)  # (B, T, 1)

        output = torch.matmul(torch.softmax(scores, dim=1).transpose(1, 2), inputs).squeeze(1)

        return output
def length_to_mask(length, max_len=None, dtype=None):
    """length: B.
    return B x max_len.
    If max_len is None, then max of length will be used.
    """
    assert len(length.shape) == 1, 'Length shape should be 1 dimensional.'
    max_len = max_len or length.max().item()
    mask = torch.arange(max_len, device=length.device,
                        dtype=length.dtype).expand(len(length), max_len) < length.unsqueeze(1)
    if dtype is not None:
        mask = torch.as_tensor(mask, dtype=dtype, device=length.device)
    return mask


