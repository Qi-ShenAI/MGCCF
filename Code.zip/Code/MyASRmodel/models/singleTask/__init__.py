#from models.missingTask.TFR_NET import TFR_NET
# from models.missingTask.EMT_DLFR import EMT_DLFR
# from models.missingTask.CIR_CR import CIR_CR
from models.singleTask.CIR import CIRP
from models.singleTask.MyASRmodel_post_bert import MyASRmodel_post_bert
from models.singleTask.Mymodel_post_bert import Mymodel_post_bert
from models.singleTask.MyASRmodel import MyASRmodel
from models.singleTask.Mymodel import Mymodel
from models.singleTask.SWRM import SWRM
from models.singleTask.SWRMbase import SWRMbase
from models.singleTask.MULT import MULT
from models.singleTask.MISA import MISA
from models.multiTask.SELF_MM import SELF_MM
from models.singleTask.MyASRmodel_post_bert_Wo_CUCL import MyASRmodel_post_bert_Wo_CUCL
from models.singleTask.MyASRmodel_post_bert_Wo_FTCL import MyASRmodel_post_bert_Wo_FTCL
from models.singleTask.MyASRmodel_post_bert_Wo_IB import MyASRmodel_post_bert_Wo_IB
from models.singleTask.MyASRmodel_post_bert_Wo_GCI import MyASRmodel_post_bert_Wo_GCI
from models.singleTask.MyASRmodel_post_bert_Wo_MICF import MyASRmodel_post_bert_Wo_MICF
from models.singleTask.Mymodel_Wo_CUCL import Mymodel_Wo_CUCL
from models.singleTask.Mymodel_Wo_FTCL import Mymodel_Wo_FTCL
from models.singleTask.Mymodel_Wo_IB import Mymodel_Wo_IB
from models.singleTask.Mymodel_Wo_GCI import Mymodel_Wo_GCI
from models.singleTask.Mymodel_Wo_MICF import Mymodel_Wo_MICF
__ALL__ = ['CIRP','MyASRmodel_post_bert','Mymodel_post_bert','MyASRmodel','Mymodel','SWRM','SWRMbase','MULT','MISA','SELF_MM', 'MyASRmodel_post_bert_Wo_CUCL', 'MyASRmodel_post_bert_Wo_FTCL', \
           'MyASRmodel_post_bert_Wo_IB','MyASRmodel_post_bert_Wo_GCI','MyASRmodel_post_bert_Wo_MICF','Mymodel_Wo_CUCL','Mymodel_Wo_FTCL','Mymodel_Wo_GCI','Mymodel_Wo_MICF']
#__ALL__ = ['TFR_NET', 'EMT_DLFR']