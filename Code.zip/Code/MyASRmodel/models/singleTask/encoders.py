import torch
import torch.nn.functional as F
import time
import math
from torch import nn
from torch.nn.utils.rnn import pad_sequence, pack_padded_sequence, pad_packed_sequence
from transformers import BertModel, BertConfig
from torch import Tensor
from torch.nn.init import constant_, xavier_normal_, xavier_uniform_
from torch.nn.parameter import Parameter
from torch import nn, einsum

from einops import rearrange, repeat

class Pro_C(nn.Module):
    def __init__(self, in_size, hidden_size, dropout):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(in_size, hidden_size), #, bias=False
                                 nn.BatchNorm1d(hidden_size),
                                 nn.Dropout(p=dropout),
                                 nn.ReLU(inplace=True),  # hidden layer
                                 nn.Linear(hidden_size, hidden_size))
                                 #nn.Sigmoid()


    def forward(self, x):
        return self.net(x)
class Pro_F(nn.Module):
    def __init__(self, in_size, hidden_size1, hidden_size2, dropout):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(in_size, hidden_size2), #, bias=False
                                 nn.BatchNorm1d(hidden_size1),
                                 nn.Dropout(p=dropout),
                                 nn.ReLU(inplace=True),  # hidden layer
                                 nn.Linear(hidden_size2, hidden_size2))
                                 #nn.Sigmoid()


    def forward(self, x):
        return self.net(x)


class LanguageEmbeddingLayer(nn.Module):
    """Embed input text with "Bert"
    """

    def __init__(self, hp):
        super(LanguageEmbeddingLayer, self).__init__()

        bertconfig = BertConfig.from_pretrained(hp.bert_path)
        bertconfig.update({'output_hidden_states': True})
        self.bertmodel = BertModel.from_pretrained(hp.bert_path, config=bertconfig)

    def forward(self, sentences, bert_sent, bert_sent_type, bert_sent_mask):
        bert_output = self.bertmodel(input_ids=bert_sent,
                                     attention_mask=bert_sent_mask,
                                     token_type_ids=bert_sent_type)
        bert_output = bert_output[0]
        return bert_output  # return head (sequence representation)


class MLP(nn.Module):
    '''
    The subnetwork that is used in TFN for video and audio in the pre-fusion stage
    '''

    def __init__(self, in_size, hidden_size, n_class, dropout, modal_name='text'):
        '''
        Args:
            in_size: input dimension
            hidden_size: hidden layer dimension
            dropout: dropout probability
        Output:
            (return value in forward) a tensor of shape (batch_size, hidden_size)
        '''
        super(MLP, self).__init__()
        # self.norm = nn.BatchNorm1d(in_size)
        self.drop = nn.Dropout(p=dropout)
        self.linear_1 = nn.Linear(in_size, hidden_size)
        self.linear_2 = nn.Linear(hidden_size, hidden_size)
        self.linear_3 = nn.Linear(hidden_size, n_class)

    def forward(self, x):
        '''
        Args:
            x: tensor of shape (batch_size, in_size)
        '''
        # normed = self.norm(x)
        dropped = self.drop(x)
        y_1 = torch.tanh(self.linear_1(dropped))
        #fusion = self.linear_2(y_1)
        y_2 = torch.tanh(self.linear_2(y_1))
        y_3 = self.linear_3(y_2)
        return y_3#, y_2#, fusion,y2
class MLPP(nn.Module):
    '''
    The subnetwork that is used in TFN for video and audio in the pre-fusion stage
    '''

    def __init__(self, in_size, hidden_size, n_class, dropout, modal_name='text'):
        '''
        Args:
            in_size: input dimension
            hidden_size: hidden layer dimension
            dropout: dropout probability
        Output:
            (return value in forward) a tensor of shape (batch_size, hidden_size)
        '''
        super(MLPP, self).__init__()
        # self.norm = nn.BatchNorm1d(in_size)
        self.drop = nn.Dropout(p=dropout)
        self.linear_1 = nn.Linear(in_size, hidden_size)
        self.linear_2 = nn.Linear(hidden_size, hidden_size)
        self.linear_3 = nn.Linear(hidden_size, n_class)

    def forward(self, x):
        '''
        Args:
            x: tensor of shape (batch_size, in_size)
        '''

        dropped = self.drop(x)
        y_1 = F.relu(self.linear_1(dropped), inplace=False)
        #fusion = self.linear_2(y_1)
        y_2 = F.relu(self.linear_2(y_1), inplace=False)
        y_3 = self.linear_3(y_2)
        return y_3
class FCMUL(nn.Module):
    def __init__(self, in_size, hidden_size, dropout):
        '''
        Args:
            in_size: input dimension
            hidden_size: hidden layer dimension
            dropout: dropout probability
        Output:
            (return value in forward) a tensor of shape (batch_size, hidden_size)
        '''
        super(FCMUL, self).__init__()
        # self.norm = nn.BatchNorm1d(in_size)
        self.drop = nn.Dropout(p=dropout)
        self.linear_1 = nn.Linear(in_size, hidden_size)
        self.Soft = nn.Softmax(dim=1)

    def forward(self, x):
        '''
        Args:
            x: tensor of shape (batch_size, in_size)
        '''
        # normed = self.norm(x)
        dropped = self.drop(x)
        y_1 = self.Soft(self.linear_1(dropped))
        return y_1
class FC(nn.Module):
    def __init__(self, in_size, hidden_size, dropout):
        '''
        Args:
            in_size: input dimension
            hidden_size: hidden layer dimension
            dropout: dropout probability
        Output:
            (return value in forward) a tensor of shape (batch_size, hidden_size)
        '''
        super(FC, self).__init__()
        # self.norm = nn.BatchNorm1d(in_size)
        self.drop = nn.Dropout(p=dropout)
        self.linear_1 = nn.Linear(in_size, hidden_size)

    def forward(self, x):
        '''
        Args:
            x: tensor of shape (batch_size, in_size)
        '''
        # normed = self.norm(x)
        dropped = self.drop(x)
        y_1 = torch.relu(self.linear_1(dropped))
        return y_1

class Pro(nn.Module):
    def __init__(self, in_size, hidden_size, dropout):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(in_size, hidden_size), #, bias=False
                                 nn.BatchNorm1d(hidden_size),
                                 nn.Dropout(p=dropout),
                                 nn.ReLU(inplace=True),  # hidden layer
                                 nn.Linear(hidden_size, hidden_size))
                                 #nn.Sigmoid()


    def forward(self, x):
        return self.net(x)

class Pru(nn.Module):
    def __init__(self, in_size, hidden_size, dropout):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(in_size, hidden_size), #, bias=False
                                 nn.Dropout(p=dropout),
                                 nn.ReLU(inplace=False),  # hidden layer
                                 nn.Linear(hidden_size, hidden_size))
                                 #nn.Sigmoid()


    def forward(self, x):
        return self.net(x)

class Prosig(nn.Module):
    def __init__(self, in_size, hidden_size, dropout):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(in_size, hidden_size), #, bias=False
                                 nn.BatchNorm1d(hidden_size),
                                 nn.Dropout(p=dropout),
                                 nn.ReLU(inplace=True),  # hidden layer
                                 nn.Linear(hidden_size, hidden_size),
                                 nn.Sigmoid())


    def forward(self, x):
        return self.net(x)
class FCC(nn.Module):
    def __init__(self, in_size, hidden_size, dropout):
        '''
        Args:
            in_size: input dimension
            hidden_size: hidden layer dimension
            dropout: dropout probability
        Output:
            (return value in forward) a tensor of shape (batch_size, hidden_size)
        '''
        super(FC, self).__init__()
        # self.norm = nn.BatchNorm1d(in_size)
        self.drop = nn.Dropout(p=dropout)
        self.linear_1 = nn.Linear(in_size, hidden_size)

    def forward(self, x):
        '''
        Args:
            x: tensor of shape (batch_size, in_size)
        '''
        # normed = self.norm(x)
        dropped = self.drop(x)
        y_1 = torch.relu(self.linear_1(dropped))
        return y_1
class FCC(nn.Module):
    def __init__(self, in_size, hidden_size, dropout):
        '''
        Args:
            in_size: input dimension
            hidden_size: hidden layer dimension
            dropout: dropout probability
        Output:
            (return value in forward) a tensor of shape (batch_size, hidden_size)
        '''
        super(FCC, self).__init__()
        #self.norm = nn.BatchNorm1d(in_size)
        self.drop = nn.Dropout(p=dropout)
        self.linear_1 = nn.Linear(in_size, hidden_size)

    def forward(self, x):
        '''
        Args:
            x: tensor of shape (batch_size, in_size)
        '''
        #print(x.shape)
        #normed = self.norm(x)
        dropped = self.drop(x)
        y_1 = torch.relu(self.linear_1(dropped))
        return y_1
# class FC(nn.Module):
#     def __init__(self, input_dim, pred_dim, output_dim):
#         super().__init__()
#         self.net = nn.Sequential(nn.Linear(input_dim, pred_dim, bias=False),#, bias=False
#                                  nn.BatchNorm1d(pred_dim),
#                                  nn.ReLU(inplace=True),  # hidden layer
#                                  nn.Linear(pred_dim, output_dim))  # output layer
#
#     def forward(self, x):
#         return self.net(x)
class FCsig(nn.Module):
    def __init__(self, in_size, hidden_size, dropout):
        '''
        Args:
            in_size: input dimension
            hidden_size: hidden layer dimension
            dropout: dropout probability
        Output:
            (return value in forward) a tensor of shape (batch_size, hidden_size)
        '''
        super(FCsig, self).__init__()
        # self.norm = nn.BatchNorm1d(in_size)
        self.drop = nn.Dropout(p=dropout)
        self.linear_1 = nn.Linear(in_size, hidden_size)
        self.sig = nn.Sigmoid()

    def forward(self, x):
        '''
        Args:
            x: tensor of shape (batch_size, in_size)
        '''
        # normed = self.norm(x)
        dropped = self.drop(x)
        y_1 = self.sig(self.linear_1(dropped))
        return y_1
class Projector(nn.Module):
    def __init__(self, input_dim, pred_dim, output_dim):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(input_dim, pred_dim), #, bias=False
                                 #nn.BatchNorm1d(pred_dim),
                                 nn.ReLU(inplace=True),  # hidden layer
                                 nn.Linear(pred_dim, output_dim),#
                                 #nn.Tanh())
                                 nn.ReLU())  # output layer

    def forward(self, x):
        return self.net(x)


class GradientReversalFn(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, alpha):
        ctx.alpha = alpha
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output):
        output = grad_output.neg() * ctx.alpha
        return output, None


class GradientReversalLayer(nn.Module):
    def __init__(self, alpha=1.0):
        super(GradientReversalLayer, self).__init__()
        self.alpha = alpha

    def forward(self, x):
        return GradientReversalFn.apply(x, self.alpha)
class PositionalEncoding(nn.Module):

    def __init__(self, d_model, dropout=0.1, max_len=5000):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)
        self.d_model = d_model
        if d_model % 2 == 1:
            dim = d_model + 1
        else:
            dim = d_model

        pe = torch.zeros(max_len, dim)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0).transpose(0, 1)
        self.register_buffer('pe', pe)

    def forward(self, x):
        # pe = self.pe[:x.size(0), :]
        # print(pe.shape)
        x = x + self.pe[:x.size(0), :, :self.d_model]
        return self.dropout(x)


class TransformerEncoder(nn.Module):

    def __init__(self, ninp=300, nhead=4, nhid=128, nlayers=3, dropout=0.5):
        super().__init__()
        from torch.nn import TransformerEncoder, TransformerEncoderLayer
        self.model_type = 'Transformer'
        self.src_mask = None
        self.pos_encoder = PositionalEncoding(ninp, dropout)
        encoder_layers = TransformerEncoderLayer(ninp, nhead, nhid, dropout, batch_first=True)
        self.transformer_encoder = TransformerEncoder(encoder_layers, nlayers)
        self.ninp = ninp

    # def generate_square_subsequent_mask(self, src, lenths):
    #     '''
    #     padding_mask
    #     src:max_lenth,batch_size,dim
    #     lenths:[lenth1,lenth2...]
    #     '''
    #
    #     # mask num_of_sens x max_lenth
    #     mask = torch.ones(src.size(0), src.size(1)) == 1  # 全部初始化为 True
    #     # batch_size, seq_length
    #     for i in range(len(lenths)):  # batch_size
    #         lenth = lenths[i]
    #         for j in range(lenth):
    #             mask[i][j] = False  # 设置前面的部分为False
    #
    #     return mask

    def generate_square_subsequent_mask(self, src, lengths):
        '''
        Generates padding mask for variable-length sequences in a batch.

        Parameters:
        src (Tensor): Input tensor with shape [max_length, batch_size, dim]
        lengths (Tensor): A tensor of sequence lengths for each sample in the batch.

        Returns:
        mask (Tensor): A mask tensor of shape [batch_size, max_length] with `False` at positions
                       within each sequence length and `True` for padded positions.
        '''

        batch_size = src.size(0)
        max_length = lengths.max().item()  # Get the max valid length in the batch
        # Initialize all positions as `True` (indicating padding)
        mask = torch.ones(batch_size, max_length, dtype=torch.bool, device=src.device)
        # Set positions up to the sequence length as `False`
        for i, length in enumerate(lengths):
            mask[i, :length] = False

        return mask

    def forward(self, src, mask):
        '''
        src:num_of_all_sens,max_lenth,300
        '''
        if mask == None:
            src = src * math.sqrt(self.ninp)
            src = self.pos_encoder(src)
            output = self.transformer_encoder(src)
            output = output

        else:
            self.src_mask = mask

            src = src * math.sqrt(self.ninp)
            src = self.pos_encoder(src)
            output = self.transformer_encoder(src, src_key_padding_mask=self.src_mask)
            output = output
        return output

    def generate_padding_mask(self, seq):
        """
        seq: tensor of shape (max_length, batch_size, embedding_dim)
        pad_token: int, the padding token id
        """
        mask = torch.ones(seq.size(1), seq.size(0)) == 1
        seq = seq.permute(1, 0, 2)  # batch, len, dim
        mask[seq[:, :, 0] != 0.0] = False  # batch_size, len
        seq = seq.permute(1, 0, 2)
        return mask.to(torch.bool)


class BimodalFusionLayer2(nn.Module):
    def __init__(self, embed_dim=768, cross_heads=12, self_heads=12, kdim=20, vdim=20,
                 attn_dropout=0.1, relu_dropout=0.1, res_dropout=0.1, attn_mask=False):
        super().__init__()
        self.embed_dim = embed_dim
        self.cross_heads = cross_heads
        self.self_heads = self_heads
        self.kdim = kdim
        self.vdim = vdim

        # self.cross_attn = nn.MultiheadAttention(
        #     embed_dim=self.embed_dim,
        #     num_heads=self.cross_heads,
        #     kdim=self.kdim,
        #     vdim=self.vdim,
        #     dropout=attn_dropout,
        #     batch_first=True
        # )
        # self.self_attn = nn.MultiheadAttention(
        #     embed_dim=self.embed_dim,
        #     num_heads=self.self_heads,
        #     dropout=attn_dropout,
        #     batch_first=True
        # )

        # self.cross_attn = MultiHeadSelfAttention(
        #     embed_dim=self.embed_dim,
        #     kdim=self.kdim,
        #     vdim=self.vdim,
        #     num_heads=self.cross_heads,
        #     dropout=attn_dropout
        #     #batch_first=True
        # )
        # self.self_attn = MultiHeadSelfAttention(
        #     embed_dim=self.embed_dim,
        #     kdim=self.embed_dim,
        #     vdim=self.embed_dim,
        #     num_heads=self.self_heads,
        #     dropout=attn_dropout
        #     #batch_first=True
        # )

        self.cross_attn = Attention(
            query_dim=self.embed_dim,
            context_dim=self.kdim,
            heads=self.cross_heads,
            dropout=attn_dropout
            # batch_first=True
        )
        self.self_attn = Attention(
            query_dim=self.embed_dim,
            context_dim=self.embed_dim,
            heads=self.self_heads,
            dropout=attn_dropout
            # batch_first=True
        )

        self.attn_mask = attn_mask

        self.relu_dropout = relu_dropout
        self.res_dropout = res_dropout

        self.fc1 = Linear(self.embed_dim, self.embed_dim)  # The "Add & Norm" part in the paper
        self.fc2 = Linear(self.embed_dim, self.embed_dim)
        self.layer_norms = nn.ModuleList([LayerNorm(self.embed_dim) for _ in range(3)])
        # self.layer_norm_q = nn.LayerNorm(self.embed_dim)
        # self.layer_norm_k = nn.LayerNorm(self.kdim)
        # self.layer_norm_v = nn.LayerNorm(self.vdim)

    def forward(self, x, x_kv, key_padding_mask, attn_mask):
        # print(x.shape)
        # print(x_k.shape)
        # print(x_v.shape)
        # exit()
        """
        Args:
            x (Tensor): input to the layer of shape `(seq_len, batch, embed_dim)`
            encoder_padding_mask (ByteTensor): binary ByteTensor of shape
                `(batch, src_len)` where padding elements are indicated by ``1``.
            x_k (Tensor): same as x
            x_v (Tensor): same as x
        Returns:
            encoded output of shape `(batch, src_len, embed_dim)`
        """
        residual = x

        # 1. attention
        # print(attn_mask)
        # print(key_padding_mask)
        # print(key_padding_mask.shape)
        # exit()
        #x, _ = self.self_attn(query=x, key=x, value=x, key_padding_mask=attn_mask)
        x, _ = self.self_attn(quary=x, context=x, key_padding_mask=attn_mask)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x
        x = self.maybe_layer_norm(0, x)  # 有层归一化

        # 2. attention
        #x, _ = self.cross_attn(query=x, key=x_k, value=x_v, key_padding_mask=key_padding_mask)
        x, _ = self.cross_attn(quary=x, context=x_kv, key_padding_mask=key_padding_mask)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x
        x = self.maybe_layer_norm(1, x)  # 层归一化

        # 3. feed forward
        residual = x

        x = F.relu(self.fc1(x))
        x = F.dropout(x, p=self.relu_dropout, training=self.training)
        x = self.fc2(x)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x
        x = self.maybe_layer_norm(2, x)  # 层归一化
        return x

    def maybe_layer_norm(self, i, x):
        return self.layer_norms[i](x)
class BimodalFusionLayer(nn.Module):
    def __init__(self, embed_dim=768, cross_heads=12, self_heads=12, kdim=20, vdim=20,
                 attn_dropout=0.1, relu_dropout=0.1, res_dropout=0.1, attn_mask=False):
        super().__init__()
        self.embed_dim = embed_dim
        self.cross_heads = cross_heads
        self.self_heads = self_heads
        self.kdim = kdim
        self.vdim = vdim

        self.cross_attn = nn.MultiheadAttention(
            embed_dim=self.embed_dim,
            num_heads=self.cross_heads,
            kdim=self.kdim,
            vdim=self.vdim,
            dropout=attn_dropout,
            batch_first=True
        )
        self.self_attn = nn.MultiheadAttention(
            embed_dim=self.embed_dim,
            num_heads=self.self_heads,
            dropout=attn_dropout,
            batch_first=True
        )

        # self.cross_attn = MultiHeadSelfAttention(
        #     embed_dim=self.embed_dim,
        #     kdim=self.kdim,
        #     vdim=self.vdim,
        #     num_heads=self.cross_heads,
        #     dropout=attn_dropout
        #     #batch_first=True
        # )
        # self.self_attn = MultiHeadSelfAttention(
        #     embed_dim=self.embed_dim,
        #     kdim=self.embed_dim,
        #     vdim=self.embed_dim,
        #     num_heads=self.self_heads,
        #     dropout=attn_dropout
        #     #batch_first=True
        # )

        # self.cross_attn = Attention(
        #     query_dim=self.embed_dim,
        #     context_dim=self.kdim,
        #     heads=self.cross_heads,
        #     dropout=attn_dropout
        #     # batch_first=True
        # )
        # self.self_attn = Attention(
        #     query_dim=self.embed_dim,
        #     context_dim=self.embed_dim,
        #     heads=self.self_heads,
        #     dropout=attn_dropout
        #     # batch_first=True
        # )

        self.attn_mask = attn_mask

        self.relu_dropout = relu_dropout
        self.res_dropout = res_dropout

        self.fc1 = Linear(self.embed_dim, self.embed_dim)  # The "Add & Norm" part in the paper
        self.fc2 = Linear(self.embed_dim, self.embed_dim)
        self.layer_norms = nn.ModuleList([LayerNorm(self.embed_dim) for _ in range(3)])
        # self.layer_norm_q = nn.LayerNorm(self.embed_dim)
        # self.layer_norm_k = nn.LayerNorm(self.kdim)
        # self.layer_norm_v = nn.LayerNorm(self.vdim)

    def forward(self, x, x_k, x_v, key_padding_mask, attn_mask):
        # print(x.shape)
        # print(x_k.shape)
        # print(x_v.shape)
        # exit()
        """
        Args:
            x (Tensor): input to the layer of shape `(seq_len, batch, embed_dim)`
            encoder_padding_mask (ByteTensor): binary ByteTensor of shape
                `(batch, src_len)` where padding elements are indicated by ``1``.
            x_k (Tensor): same as x
            x_v (Tensor): same as x
        Returns:
            encoded output of shape `(batch, src_len, embed_dim)`
        """
        residual = x

        # 1. attention
        # print(attn_mask)
        # print(key_padding_mask)
        # print(key_padding_mask.shape)
        # exit()
        x, _ = self.self_attn(query=x, key=x, value=x, key_padding_mask=attn_mask)
        #x, _ = self.self_attn(quary=x, context=x, key_padding_mask=attn_mask)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x
        x = self.maybe_layer_norm(0, x)  # 有层归一化
        #residual = x
        # 2. attention
        x, _ = self.cross_attn(query=x, key=x_k, value=x_v, key_padding_mask=key_padding_mask)
        #x, _ = self.cross_attn(quary=x, context=x_kv, key_padding_mask=key_padding_mask)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x
        x = self.maybe_layer_norm(1, x)  # 层归一化

        # 3. feed forward
        residual = x

        x = F.relu(self.fc1(x))
        x = F.dropout(x, p=self.relu_dropout, training=self.training)
        x = self.fc2(x)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x
        x = self.maybe_layer_norm(2, x)  # 层归一化
        return x

    def maybe_layer_norm(self, i, x):
        return self.layer_norms[i](x)

class BBimodalFusionLayer(nn.Module):
    def __init__(self, embed_dim=768, cross_heads=12, self_heads=12, kdim=20, vdim=20,
                 attn_dropout=0.1, relu_dropout=0.1, res_dropout=0.1, attn_mask=False):
        super().__init__()
        self.embed_dim = embed_dim
        self.cross_heads = cross_heads
        self.self_heads = self_heads
        self.kdim = kdim
        self.vdim = vdim

        self.cross_attn = nn.MultiheadAttention(
            embed_dim=self.embed_dim,
            num_heads=self.cross_heads,
            kdim=self.kdim,
            vdim=self.vdim,
            dropout=attn_dropout,
            batch_first=True
        )
        self.attn_mask = attn_mask

        self.relu_dropout = relu_dropout
        self.res_dropout = res_dropout

        self.fc1 = Linear(self.embed_dim, self.embed_dim)  # The "Add & Norm" part in the paper
        self.fc2 = Linear(self.embed_dim, self.embed_dim)
        self.layer_norms = nn.ModuleList([LayerNorm(self.embed_dim) for _ in range(3)])
        # self.layer_norm_q = nn.LayerNorm(self.embed_dim)
        # self.layer_norm_k = nn.LayerNorm(self.kdim)
        # self.layer_norm_v = nn.LayerNorm(self.vdim)

    def forward(self, x, x_k, x_v, key_padding_mask, attn_mask):
        # print(x.shape)
        # print(x_k.shape)
        # print(x_v.shape)
        # exit()
        """
        Args:
            x (Tensor): input to the layer of shape `(seq_len, batch, embed_dim)`
            encoder_padding_mask (ByteTensor): binary ByteTensor of shape
                `(batch, src_len)` where padding elements are indicated by ``1``.
            x_k (Tensor): same as x
            x_v (Tensor): same as x
        Returns:
            encoded output of shape `(batch, src_len, embed_dim)`
        """
        residual = x
        x, _ = self.cross_attn(query=x, key=x_k, value=x_v, key_padding_mask=key_padding_mask)
        #x, _ = self.cross_attn(quary=x, context=x_kv, key_padding_mask=key_padding_mask)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x
        x = self.maybe_layer_norm(1, x)  # 层归一化
        residual = x
        x, _ = self.self_attn(query=x, key=x, value=x, key_padding_mask=attn_mask)
        # x, _ = self.self_attn(quary=x, context=x, key_padding_mask=attn_mask)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x
        x = self.maybe_layer_norm(0, x)  # 有层归一化

        # 3. feed forward
        residual = x
        x = F.relu(self.fc1(x))
        x = F.dropout(x, p=self.relu_dropout, training=self.training)
        x = self.fc2(x)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x
        x = self.maybe_layer_norm(2, x)  # 层归一化
        return x

    def maybe_layer_norm(self, i, x):
        return self.layer_norms[i](x)
class AttenLayer(nn.Module):
    def __init__(self, embed_dim=768, cross_heads=12, self_heads=12, kdim=20, vdim=20,
                 attn_dropout=0.1, relu_dropout=0.1, res_dropout=0.1, attn_mask=False):
        super().__init__()
        self.embed_dim = embed_dim
        self.cross_heads = cross_heads
        self.self_heads = self_heads
        self.kdim = kdim
        self.vdim = vdim
        self.cross_attn = nn.MultiheadAttention(
            embed_dim=self.embed_dim,
            num_heads=self.cross_heads,
            kdim=self.kdim,
            vdim=self.vdim,
            dropout=attn_dropout,
            batch_first=True
        )
    def forward(self, x, x_k, x_v, key_padding_mask, attn_mask):
        # print(x.shape)
        # print(x_k.shape)
        # print(x_v.shape)
        # exit()
        """
        Args:
            x (Tensor): input to the layer of shape `(seq_len, batch, embed_dim)`
            encoder_padding_mask (ByteTensor): binary ByteTensor of shape
                `(batch, src_len)` where padding elements are indicated by ``1``.
            x_k (Tensor): same as x
            x_v (Tensor): same as x
        Returns:
            encoded output of shape `(batch, src_len, embed_dim)`
        """
        x, atten = self.cross_attn(query=x, key=x_k, value=x_v, key_padding_mask=key_padding_mask)
        return x, atten

    def maybe_layer_norm(self, i, x):
        return self.layer_norms[i](x)
class FeedForward(nn.Module):
    def __init__(self, dim, mult=4, dropout=0.):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, dim * mult * 2),
            GEGLU(),
            nn.Linear(dim * mult, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        return self.net(x)
class GEGLU(nn.Module):
    def forward(self, x):
        x, gates = x.chunk(2, dim=-1)
        return x * F.gelu(gates)
class BBimodalFusionLayer(nn.Module):
    def __init__(self, embed_dim=768, cross_heads=12, self_heads=12, kdim=20, vdim=20,
                 attn_dropout=0.1, relu_dropout=0.1, res_dropout=0.1, attn_mask=False):
        super().__init__()
        self.embed_dim = embed_dim
        self.cross_heads = cross_heads
        self.self_heads = self_heads
        self.kdim = kdim
        self.vdim = vdim

        self.cross_attn = nn.MultiheadAttention(
            embed_dim=self.embed_dim,
            num_heads=self.cross_heads,
            kdim=self.kdim,
            vdim=self.vdim,
            dropout=attn_dropout,
            batch_first=True
        )
        self.self_attn = nn.MultiheadAttention(
            embed_dim=self.embed_dim,
            num_heads=self.self_heads,
            dropout=attn_dropout,
            batch_first=True
        )

        self.attn_mask = attn_mask
        self.relu_dropout = relu_dropout
        self.res_dropout = res_dropout
        self.ff = FeedForward(self.embed_dim, mult=4, dropout=self.res_dropout)



        # self.fc1 = Linear(self.embed_dim, self.embed_dim)  # The "Add & Norm" part in the paper
        # self.fc2 = Linear(self.embed_dim, self.embed_dim)
        self.layer_norms = nn.ModuleList([LayerNorm(self.embed_dim) for _ in range(3)])

    def forward(self, x, x_k, x_v, key_padding_mask, attn_mask):
        residual = x
        x = self.maybe_layer_norm(0, x)  # 有层归一化
        x, _ = self.cross_attn(query=x, key=x_k, value=x_v, key_padding_mask=key_padding_mask)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x

        residual = x
        x = self.maybe_layer_norm(0, x)  # 有层归一化
        x, _ = self.self_attn(query=x, key=x, value=x, key_padding_mask=attn_mask)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x

        residual = x
        x = self.maybe_layer_norm(1, x)  # 层归一化
        # 3. feed forward
        x = self.ff(x)
        x = residual + x
        return x

    def maybe_layer_norm(self, i, x):
        return self.layer_norms[i](x)
class TrimodalFusionLayer(nn.Module):
    def __init__(self, embed_dim=768, cross_heads=12, self_heads=12, kdim=384, vdim=384,
                 attn_dropout=0.1, relu_dropout=0.1, res_dropout=0.1, attn_mask=False):
        super().__init__()
        self.embed_dim = embed_dim
        self.cross_heads = cross_heads
        self.self_heads = self_heads
        self.kdim = kdim
        self.vdim = vdim

        self.cross_attn = nn.MultiheadAttention(
            embed_dim=self.embed_dim,
            num_heads=self.cross_heads,
            kdim=self.kdim,
            vdim=self.vdim,
            dropout=attn_dropout,
            batch_first=True
        )
        self.self_attn = nn.MultiheadAttention(
            embed_dim=self.embed_dim,
            num_heads=self.self_heads,
            dropout=attn_dropout,
            batch_first=True
        )

        self.attn_mask = attn_mask

        self.relu_dropout = relu_dropout
        self.res_dropout = res_dropout

        self.fc1 = Linear(self.embed_dim, self.embed_dim)  # The "Add & Norm" part in the paper
        self.fc2 = Linear(self.embed_dim, self.embed_dim)
        self.layer_norms = nn.ModuleList([LayerNorm(self.embed_dim) for _ in range(3)])
        # self.layer_norm_q = nn.LayerNorm(self.embed_dim)
        # self.layer_norm_k = nn.LayerNorm(self.kdim)
        # self.layer_norm_v = nn.LayerNorm(self.vdim)

    def forward(self, x, x_k, x_v, key_padding_mask, attn_mask):
        # print(x.shape)
        # print(x_k.shape)
        # print(x_v.shape)
        # exit()
        """
        Args:
            x (Tensor): input to the layer of shape `(seq_len, batch, embed_dim)`
            encoder_padding_mask (ByteTensor): binary ByteTensor of shape
                `(batch, src_len)` where padding elements are indicated by ``1``.
            x_k (Tensor): same as x
            x_v (Tensor): same as x
        Returns:
            encoded output of shape `(batch, src_len, embed_dim)`
        """
        residual = x

        x, _ = self.self_attn(query=x, key=x, value=x, key_padding_mask=attn_mask)
        #x, _ = self.self_attn(quary=x, context=x, key_padding_mask=attn_mask)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x
        x = self.maybe_layer_norm(0, x)  # 有层归一化
        residual = x
        #2. attention
        x, _ = self.cross_attn(query=x, key=x_k, value=x_v, key_padding_mask=key_padding_mask)
        #x, _ = self.cross_attn(quary=x, context=x_kv, key_padding_mask=key_padding_mask)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x
        x = self.maybe_layer_norm(1, x)  # 层归一化

        # 3. feed forward
        residual = x

        x = F.relu(self.fc1(x))
        x = F.dropout(x, p=self.relu_dropout, training=self.training)
        x = self.fc2(x)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x
        x = self.maybe_layer_norm(2, x)  # 层归一化
        return x

    def maybe_layer_norm(self, i, x):
        return self.layer_norms[i](x)
class BimodalFusionLayer1(nn.Module):
    def __init__(self, embed_dim=768, cross_heads=12, self_heads=12, kdim=20, vdim=20,
                 attn_dropout=0.1, relu_dropout=0.1, res_dropout=0.1, attn_mask=False):
        super().__init__()
        self.embed_dim = embed_dim
        self.cross_heads = cross_heads
        self.self_heads = self_heads
        self.kdim = kdim
        self.vdim = vdim

        self.cross_attn = nn.MultiheadAttention(
            embed_dim=self.embed_dim,
            num_heads=self.cross_heads,
            kdim=self.kdim,
            vdim=self.vdim,
            dropout=attn_dropout,
            batch_first=True
        )
        self.self_attn = nn.MultiheadAttention(
            embed_dim=self.embed_dim,
            num_heads=self.self_heads,
            dropout=attn_dropout,
            batch_first=True
        )

        # self.cross_attn = MultiHeadSelfAttention(
        #     embed_dim=self.embed_dim,
        #     kdim=self.kdim,
        #     vdim=self.vdim,
        #     num_heads=self.cross_heads,
        #     dropout=attn_dropout
        #     #batch_first=True
        # )
        # self.self_attn = MultiHeadSelfAttention(
        #     embed_dim=self.embed_dim,
        #     kdim=self.embed_dim,
        #     vdim=self.embed_dim,
        #     num_heads=self.self_heads,
        #     dropout=attn_dropout
        #     #batch_first=True
        # )

        # self.cross_attn = Attention(
        #     query_dim=self.embed_dim,
        #     context_dim=self.kdim,
        #     heads=self.cross_heads,
        #     dropout=attn_dropout
        #     # batch_first=True
        # )
        # self.self_attn = Attention(
        #     query_dim=self.embed_dim,
        #     context_dim=self.embed_dim,
        #     heads=self.self_heads,
        #     dropout=attn_dropout
        #     # batch_first=True
        # )

        self.attn_mask = attn_mask

        self.relu_dropout = relu_dropout
        self.res_dropout = res_dropout

        self.fc1 = Linear(self.embed_dim, self.embed_dim)  # The "Add & Norm" part in the paper
        self.fc2 = Linear(self.embed_dim, self.embed_dim)
        self.layer_norms = nn.ModuleList([LayerNorm(self.embed_dim) for _ in range(3)])
        # self.layer_norm_q = nn.LayerNorm(self.embed_dim)
        # self.layer_norm_k = nn.LayerNorm(self.kdim)
        # self.layer_norm_v = nn.LayerNorm(self.vdim)

    def forward(self, x, x_k, x_v, key_padding_mask, attn_mask):
        # print(x.shape)
        # print(x_k.shape)
        # print(x_v.shape)
        # exit()
        """
        Args:
            x (Tensor): input to the layer of shape `(seq_len, batch, embed_dim)`
            encoder_padding_mask (ByteTensor): binary ByteTensor of shape
                `(batch, src_len)` where padding elements are indicated by ``1``.
            x_k (Tensor): same as x
            x_v (Tensor): same as x
        Returns:
            encoded output of shape `(batch, src_len, embed_dim)`
        """
        residual = x
        # 1. attention
        x, _ = self.cross_attn(query=x, key=x_k, value=x_v, key_padding_mask=key_padding_mask)
        #x, _ = self.cross_attn(quary=x, context=x_kv, key_padding_mask=key_padding_mask)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x
        x = self.maybe_layer_norm(0, x)  # 层归一化
        residual = x
        x, _ = self.self_attn(query=x, key=x, value=x, key_padding_mask=attn_mask)
        # x, _ = self.self_attn(quary=x, context=x, key_padding_mask=attn_mask)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x
        x = self.maybe_layer_norm(1, x)  # 有层归一化

        # 3. feed forward
        residual = x

        x = F.relu(self.fc1(x))
        x = F.dropout(x, p=self.relu_dropout, training=self.training)
        x = self.fc2(x)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x
        x = self.maybe_layer_norm(2, x)  # 层归一化
        return x

    def maybe_layer_norm(self, i, x):
        return self.layer_norms[i](x)
class BimodalInverseFusionLayer(nn.Module):
    def __init__(self, embed_dim=768, cross_heads=12, self_heads=12, kdim=20, vdim=20,
                 attn_dropout=0.1, relu_dropout=0.1, res_dropout=0.1, attn_mask=False):
        super().__init__()
        self.embed_dim = embed_dim
        self.cross_heads = cross_heads
        self.self_heads = self_heads
        self.kdim = kdim
        self.vdim = vdim

        # self.cross_attn = nn.MultiheadAttention(
        #     embed_dim=self.embed_dim,
        #     num_heads=self.cross_heads,
        #     kdim=self.kdim,
        #     vdim=self.vdim,
        #     dropout=attn_dropout,
        #     batch_first=True
        # )
        # self.self_attn = nn.MultiheadAttention(
        #     embed_dim=self.embed_dim,
        #     num_heads=self.self_heads,
        #     dropout=attn_dropout,
        #     batch_first=True
        # )

        # self.cross_attn = MultiHeadSelfAttention(
        #     embed_dim=self.embed_dim,
        #     kdim=self.kdim,
        #     vdim=self.vdim,
        #     num_heads=self.cross_heads,
        #     dropout=attn_dropout
        #     #batch_first=True
        # )
        # self.self_attn = MultiHeadSelfAttention(
        #     embed_dim=self.embed_dim,
        #     kdim=self.embed_dim,
        #     vdim=self.embed_dim,
        #     num_heads=self.self_heads,
        #     dropout=attn_dropout
        #     #batch_first=True
        # )

        self.cross_attn = InverseAttention(
            query_dim=self.embed_dim,
            context_dim=self.kdim,
            heads=self.cross_heads,
            dropout=attn_dropout
            # batch_first=True
        )
        self.self_attn = InverseAttention(
            query_dim=self.embed_dim,
            context_dim=self.embed_dim,
            heads=self.self_heads,
            dropout=attn_dropout
            # batch_first=True
        )

        self.attn_mask = attn_mask

        self.relu_dropout = relu_dropout
        self.res_dropout = res_dropout

        self.fc1 = Linear(self.embed_dim, self.embed_dim)  # The "Add & Norm" part in the paper
        self.fc2 = Linear(self.embed_dim, self.embed_dim)
        self.layer_norms = nn.ModuleList([LayerNorm(self.embed_dim) for _ in range(3)])
        # self.layer_norm_q = nn.LayerNorm(self.embed_dim)
        # self.layer_norm_k = nn.LayerNorm(self.kdim)
        # self.layer_norm_v = nn.LayerNorm(self.vdim)

    def forward(self, x, x_kv, key_padding_mask, attn_mask):
        """
        Args:
            x (Tensor): input to the layer of shape `(seq_len, batch, embed_dim)`
            encoder_padding_mask (ByteTensor): binary ByteTensor of shape
                `(batch, src_len)` where padding elements are indicated by ``1``.
            x_k (Tensor): same as x
            x_v (Tensor): same as x
        Returns:
            encoded output of shape `(batch, src_len, embed_dim)`
        """
        residual = x

        # 1. attention

        x, _ = self.self_attn(quary=x, context=x, key_padding_mask=attn_mask)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x
        x = self.maybe_layer_norm(0, x)  # 有层归一化

        # 2. attention

        x, _ = self.cross_attn(quary=x, context=x_kv, key_padding_mask=key_padding_mask)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x
        x = self.maybe_layer_norm(1, x)  # 层归一化

        # 3. feed forward
        residual = x

        x = F.relu(self.fc1(x))
        x = F.dropout(x, p=self.relu_dropout, training=self.training)
        x = self.fc2(x)
        x = F.dropout(x, p=self.res_dropout, training=self.training)
        x = residual + x
        x = self.maybe_layer_norm(2, x)  # 层归一化
        return x

    def maybe_layer_norm(self, i, x):
        return self.layer_norms[i](x)



def exists(val):
    return val is not None


def default(val, d):
    return val if exists(val) else d
class Attention(nn.Module):
    def __init__(self, query_dim, context_dim = None, heads = 8, dim_head = 64, dropout = 0.):
        super().__init__()
        inner_dim = dim_head * heads
        context_dim = default(context_dim, query_dim)

        self.scale = dim_head ** -0.5
        self.heads = heads

        self.to_q = nn.Linear(query_dim, inner_dim, bias = False)
        self.to_kv = nn.Linear(context_dim, inner_dim * 2, bias = False)

        self.dropout = nn.Dropout(dropout)
        self.to_out = nn.Linear(inner_dim, query_dim)

    def forward(self, x, context = None, mask = None):
        h = self.heads

        q = self.to_q(x)
        context = default(context, x)
        k, v = self.to_kv(context).chunk(2, dim = -1)

        q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> (b h) n d', h = h), (q, k, v))

        sim = einsum('b i d, b j d -> b i j', q, k) * self.scale

        if exists(mask):
            mask = rearrange(mask, 'b ... -> b (...)')
            max_neg_value = -torch.finfo(sim.dtype).max
            mask = repeat(mask, 'b j -> (b h) () j', h = h)
            sim.masked_fill_(~mask, max_neg_value)

        # attention, what we cannot get enough of
        attn = sim.softmax(dim = -1)
        attn = self.dropout(attn)

        out = einsum('b i j, b j d -> b i d', attn, v)
        out = rearrange(out, '(b h) n d -> b n (h d)', h = h)
        return self.to_out(out)


class InverseAttention(nn.Module):
    def __init__(self, query_dim, context_dim=None, heads=12, dim_head=64, dropout=0.):
        super().__init__()
        inner_dim = dim_head * heads
        context_dim = default(context_dim, query_dim)
        self.scale = dim_head ** -0.5
        self.heads = heads
        self.to_q = nn.Linear(query_dim, inner_dim, bias=False)
        self.to_kv = nn.Linear(context_dim, inner_dim * 2, bias=False)
        self.dropout = nn.Dropout(dropout)
        self.to_out = nn.Linear(inner_dim, query_dim)

    def forward(self, quary, context, key_padding_mask):
        h = self.heads

        q = self.to_q(quary)
        context = default(context, quary)
        k, v = self.to_kv(context).chunk(2, dim=-1)

        q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> (b h) n d', h=h), (q, k, v))

        sim = einsum('b i d, b j d -> b i j', q, k) * self.scale
        #print(sim.shape)
        # print(q.shape)
        # print(k.shape)
        # print(v.shape)
        # print("#")



        if exists(key_padding_mask):
            mask = rearrange(key_padding_mask, 'b ... -> b (...)')
            max_neg_value = -torch.finfo(sim.dtype).max
            mask = repeat(mask, 'b j -> (b h) () j', h=h) # (B*h, 1, T2)
            sim.masked_fill_(mask, max_neg_value)

        # attention, what we cannot get enough of
        #sim = torch.inverse(sim)
        attn = sim.softmax(dim=-1)
        attn = self.dropout(attn)

        out = einsum('b i j, b j d -> b i d', attn, v)
        out = rearrange(out, '(b h) n d -> b n (h d)', h=h)
        #print(attn.shape)
        return self.to_out(out), attn

def fill_with_neg_inf(t):
    """FP16-compatible function that fills a tensor with -inf."""
    return t.float().fill_(float('-inf')).type_as(t)


def buffered_future_mask(tensor, tensor2=None):
    dim1 = dim2 = tensor.size(0)
    if tensor2 is not None:
        dim2 = tensor2.size(0)
    future_mask = torch.triu(fill_with_neg_inf(torch.ones(dim1, dim2)), 1 + abs(dim2 - dim1))
    if tensor.is_cuda:
        future_mask = future_mask.cuda()
    return future_mask[:dim1, :dim2]


def Linear(in_features, out_features, bias=True):
    m = nn.Linear(in_features, out_features, bias)
    nn.init.xavier_uniform_(m.weight)
    if bias:
        nn.init.constant_(m.bias, 0.)
    return m


def LayerNorm(embedding_dim):
    m = nn.LayerNorm(embedding_dim)
    return m
