"""
AIO -- All Trains in One
"""

from trains.singleTask import *
from trains.multiTask import *
__all__ = ['ATIO']

class ATIO():
    def __init__(self):
        self.TRAIN_MAP = {
            # single-task
            'cirp': CIRP,
            'myasrmodel_post_bert': MyASRmodel_post_bert,
            'mymodel_post_bert': Mymodel_post_bert,
            'myasrmodel': MyASRmodel,
            'mymodel': Mymodel,
            'swrm': SWRM,
            'swrmbase': SWRMbase,
            'mult': MULT,
            'misa': MISA,
            'self_mm': SELF_MM,
            'emt_dlfr': EMT_DLFR,
            'myasrmodel_post_bert_wo_cucl': MyASRmodel_post_bert_Wo_CUCL,
            'myasrmodel_post_bert_wo_ftcl': MyASRmodel_post_bert_Wo_FTCL,
            'myasrmodel_post_bert_wo_ib': MyASRmodel_post_bert_Wo_IB,
            'myasrmodel_post_bert_wo_gci': MyASRmodel_post_bert_Wo_GCI,
            'myasrmodel_post_bert_wo_micf': MyASRmodel_post_bert_Wo_MICF,
            'mymodel_wo_cucl': Mymodel_Wo_CUCL,
            'mymodel_wo_ftcl': Mymodel_Wo_FTCL,
            'mymodel_wo_ib': Mymodel_Wo_IB,
            'mymodel_wo_gci': Mymodel_Wo_GCI,
            'mymodel_wo_micf': Mymodel_Wo_MICF,

        }
    
    def getTrain(self, args):
        # print(args.modelName.lower())
        # print(args.modelName)
        return self.TRAIN_MAP[args.modelName.lower()](args)
