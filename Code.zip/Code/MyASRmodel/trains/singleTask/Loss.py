from __future__ import print_function

import torch
import math
import torch.nn.functional as F
LARGE_NUM = 1e9
from torch.nn import L1Loss
import torch.nn as nn
import numpy as np
class IBLoss(nn.Module):
    def __init__(self, beta = 1e-3):
        super(IBLoss, self).__init__()
        self.beta = beta
        self.loss_fct = L1Loss()
    def forward(self, y_pred, y, mu, std):
        CE = self.loss_fct(y_pred.view(-1, ), y.view(-1, ))
        KL = 0.5 * torch.mean(mu.pow(2) + std.pow(2) - 2 * std.log() - 1)
        return (self.beta * KL + CE)

class Fine_ConLoss(nn.Module):
    """Supervised Contrastive Learning: https://arxiv.org/pdf/2004.11362.pdf.
    It also supports the unsupervised contrastive loss in SimCLR"""
    def __init__(self, temperature=0.2, contrast_mode='all'):#0.3
        super(Fine_ConLoss, self).__init__()
        self.temperature = temperature
        self.contrast_mode = contrast_mode
        # self.base_temperature = base_temperature
    def forward(self, f1, f2, labels=None, mask=None):
        """Compute loss for model. If both `labels` and `mask` are None,
        it degenerates to SimCLR unsupervised loss:
        https://arxiv.org/pdf/2002.05709.pdf
        Args:
            features: hidden vector of shape [bsz, n_views, ...].
            labels: ground truth of shape [bsz].
            mask: contrastive mask of shape [bsz, bsz], mask_{i,j}=1 if sample j
                has the same class as sample i. Can be asymmetric.
        Returns:
            A loss scalar.
        """
        f1 = torch.nn.functional.normalize(f1, p=2, dim=-1)
        f2 = torch.nn.functional.normalize(f2, p=2, dim=-1)
        device = (torch.device('cuda')
                  if f1.is_cuda
                  else torch.device('cpu'))

        batch_size = f1.shape[0]
        if labels is not None and mask is not None:
            raise ValueError('Cannot define both `labels` and `mask`')
        elif labels is None and mask is None:
            mask = torch.eye(batch_size, dtype=torch.float32).to(device)
        elif labels is not None:
            labels = labels.contiguous().view(-1, 1)
            if labels.shape[0] != batch_size:
                raise ValueError('Num of labels does not match num of features')
            #mask = torch.eq(labels, labels.T).float().to(device)
        else:
            mask = mask.float().to(device)

        contrast_count = 2  # 2
        #contrast_feature = torch.cat(torch.unbind(features, dim=1), dim=0)

        contrast_feature = f2
        if self.contrast_mode == 'one':
            anchor_feature = f1
            anchor_count = 1
        elif self.contrast_mode == 'all':
            anchor_feature = f1
            anchor_count = contrast_count  # 2
        else:
            raise ValueError('Unknown mode: {}'.format(self.contrast_mode))
        # compute logits
        # anchor_dot_contrast = torch.div(
        #     torch.matmul(anchor_feature.unsqueeze(2), contrast_feature.unsqueeze(1).transpose(1, 2)),  # bs,bs
        #     self.temperature)
        anchor_dot_contrast = torch.div(torch.matmul(anchor_feature.unsqueeze(1), contrast_feature.unsqueeze(0).transpose(2, 3)),  # bs,bs
            self.temperature)
        # print(anchor_dot_contrast.shape)
        # exit()
        row_weights = torch.softmax(anchor_dot_contrast, dim=2)
        row_weights_anchor_dot_contrast = torch.sum(row_weights * anchor_dot_contrast, dim=2)
        col_weights = torch.softmax(row_weights_anchor_dot_contrast, dim=2)
        col_weights_anchor_dot_contrast = torch.sum(col_weights * row_weights_anchor_dot_contrast, dim=2)

        logits_max, _ = torch.max(col_weights_anchor_dot_contrast, dim=1, keepdim=True)
        logits = col_weights_anchor_dot_contrast - logits_max.detach()
        # tile mask
        #mask = mask.repeat(anchor_count, contrast_count)
        # mask-out self-contrast cases
        logits_mask = torch.scatter(
            torch.ones_like(mask),
            1,
            torch.arange(batch_size).view(-1, 1).to(device),
            0
        )  # bs,bs,
        #exit()
        #mask = mask * logits_mask
        # compute log_prob


        exp_logits = torch.exp(logits) * logits_mask
        log_prob = logits - torch.log(exp_logits.sum(1, keepdim=True))
        # log(a/b) = loga - logb
        # compute mean of log-likelihood over positive
        mean_log_prob_pos = (mask * log_prob).sum(1) / mask.sum(1)
        # loss
        #loss = - (self.temperature / self.base_temperature) * mean_log_prob_pos
        loss = -mean_log_prob_pos
        loss = loss.view(batch_size).mean()

        return loss

EPISILON=1e-10
class XCoarse_SupConLoss(torch.nn.Module):
    def __init__(self, temperature=0.1, lamuda=1.5):
        super(XCoarse_SupConLoss, self).__init__()
        self.temperature = temperature
        self.softmax = nn.Softmax(dim=1)
        self.lamuda = lamuda
    def where(self, cond, x_1, x_2):
        cond = cond.type(torch.float32)
        return (cond * x_1) + ((1 - cond) * x_2)
    def forward(self, f1, f2, targets):
        f1 = F.normalize(f1, dim=1)
        f2 = F.normalize(f2, dim=1)
        device = (torch.device('cuda')
                  if f1.is_cuda
                  else torch.device('cpu'))

        # distance_targets = abs(targets.unsqueeze(1) - targets)
        # mask_distance = (distance_targets>self.d).bool()
        # polarity_targets = (targets<0).int()
        # mask_polarity = abs(polarity_targets.unsqueeze(1)-polarity_targets).bool()
        #self_mask = (mask_distance + mask_polarity).int()
        targets = targets.contiguous().view(-1, 1)
        mask = ((targets * targets.T > 0) | ((targets == 0) & (targets.T == 0))).float().to(device)
        self_mask = 1 - mask
        distance = torch.abs(targets - targets.T)

        num_weights_mask = (-torch.tanh(mask * distance) + 1) * mask  # 分子
        den_weights_mask = torch.tanh(self_mask * distance) * self_mask  # 分母

        total_weight_mask = num_weights_mask + den_weights_mask

        dist = (f1.unsqueeze(1) - f2).pow(2).sum(2)
        cos = (1 - 0.5 * dist) * total_weight_mask# weight
        pred_softmax = F.softmax(cos / self.temperature,dim=1)
        log_pos_softmax = - torch.log(pred_softmax + EPISILON) * mask#biger
        log_neg_softmax = - torch.log(1 - pred_softmax + EPISILON) * self_mask#smaller
        if self_mask.sum() == 0:
            log_softmax = log_pos_softmax.sum(1) / (1 - self_mask).sum(1).float()
        else:
            log_softmax = log_pos_softmax.sum(1) / (1 - self_mask).sum(1).float() + log_neg_softmax.sum(
                1) / self_mask.sum(1).float()
        loss = log_softmax
        return loss.mean()

class Coarse_SupConLoss(nn.Module):
    """Supervised Contrastive Learning: https://arxiv.org/pdf/2004.11362.pdf.
    It also supports the unsupervised contrastive loss in SimCLR"""
    def __init__(self, temperature= 1.2, t_w = 0.2, lamda = 2, contrast_mode='all'):#0.3 0.5temperature_w = 2.0
        super(Coarse_SupConLoss, self).__init__()
        self.temperature = temperature
        self.t_w = t_w
        self.contrast_mode = contrast_mode
        self.lamda = lamda
        # self.base_temperature = base_temperature
    def forward(self, f1, f2, labels=None, mask=None):
        """Compute loss for model. If both `labels` and `mask` are None,
        it degenerates to SimCLR unsupervised loss:
        https://arxiv.org/pdf/2002.05709.pdf
        Args:
            features: hidden vector of shape [bsz, n_views, ...].
            labels: ground truth of shape [bsz].
            mask: contrastive mask of shape [bsz, bsz], mask_{i,j}=1 if sample j
                has the same class as sample i. Can be asymmetric.
        Returns:
            A loss scalar.
        """
        f1 = torch.nn.functional.normalize(f1, p=2, dim=-1)
        f2 = torch.nn.functional.normalize(f2, p=2, dim=-1)
        device = (torch.device('cuda')
                  if f1.is_cuda
                  else torch.device('cpu'))

        batch_size = f1.shape[0]
        if labels is not None and mask is not None:
            raise ValueError('Cannot define both `labels` and `mask`')
        elif labels is None and mask is None:
            mask = torch.eye(batch_size, dtype=torch.float32).to(device)
        elif labels is not None:
            labels = labels.contiguous().view(-1, 1)
            if labels.shape[0] != batch_size:
                raise ValueError('Num of labels does not match num of features')
            #mask = torch.eq(labels, labels.T).float().to(device)
            mask = ((labels * labels.T > 0) | ((labels == 0) & (labels.T == 0))).float().to(device)
            self_mask = 1 - mask
            distance = torch.abs(labels - labels.T)

            # num_weights_mask = self.lamda * (-torch.tanh(mask * distance / self.temperature_w) + 1) * mask  # 分子 #2
            # den_weights_mask = self.lamda * torch.tanh(self_mask * distance / self.temperature_w) * self_mask  # 分母
            # distance_num = distance / 3
            # distance_den = distance / 3
            # num_weights_mask = self.lamda * (torch.sigmoid(mask * (-distance) / self.temperature_w) + 0.5) * mask  # 分子 #2
            # den_weights_mask = self.lamda * (torch.sigmoid(self_mask * (distance) / self.temperature_w)) * self_mask  # 分母

            #
            num_weights_mask = self.lamda * torch.sigmoid(mask * self.t_w * (-distance)) * mask  # 分子 #2
            den_weights_mask = self.lamda * (torch.sigmoid(self_mask * self.t_w * distance) - 0.5) * self_mask  # 分母
            #num_weights_mask = (mask * (3.0 - distance) / self.temperature_w) * mask  # 分子 #2
            #den_weights_mask = (self_mask * distance / (self.temperature_w * 2)) * self_mask  # 分母

            total_weight_mask = num_weights_mask + den_weights_mask

        else:
            mask = mask.float().to(device)

        contrast_count = 2  # 2
        #contrast_feature = torch.cat(torch.unbind(features, dim=1), dim=0)

        contrast_feature = f2
        if self.contrast_mode == 'one':
            anchor_feature = f1
            anchor_count = 1
        elif self.contrast_mode == 'all':
            anchor_feature = f1
            anchor_count = contrast_count  # 2
        else:
            raise ValueError('Unknown mode: {}'.format(self.contrast_mode))
        # compute logits
        # anchor_dot_contrast = torch.div(
        #     torch.matmul(anchor_feature.unsqueeze(2), contrast_feature.unsqueeze(1).transpose(1, 2)),  # bs,bs
        #     self.temperature)
        anchor_dot_contrast = torch.div(
            torch.matmul(anchor_feature, contrast_feature.T),  # bs,bs
            self.temperature)
        logits_max, _ = torch.max(anchor_dot_contrast, dim=1, keepdim=True)
        logits = anchor_dot_contrast - logits_max.detach()
        weight_logits = logits * total_weight_mask
        # tile mask
        #mask = mask.repeat(anchor_count, contrast_count)
        # mask-out self-contrast cases
        # logits_mask = torch.scatter(
        #     torch.ones_like(mask),
        #     1,
        #     torch.arange(batch_size).view(-1, 1).to(device),
        #     0
        # )  # bs,bs,
        #exit()
        #mask = mask * logits_mask
        # compute log_prob
        exp_logits = self_mask * torch.exp(weight_logits)
        if self_mask.sum() != 0:
            log_prob = weight_logits - torch.log((exp_logits).sum(1, keepdim=True))
        else:
            log_prob = weight_logits
        # log(a/b) = loga - logb
        # compute mean of log-likelihood over positive
        mean_log_prob_pos = (mask * log_prob).sum(1) / mask.sum(1)
        # loss
        #loss = - (self.temperature / self.base_temperature) * mean_log_prob_pos
        loss = -mean_log_prob_pos
        loss = loss.view(batch_size).mean()

        return loss

"""
class XFine_SupConLoss(torch.nn.Module):
    def __init__(self, temperature=0.1):
        super(XFine_SupConLoss, self).__init__()
        self.temperature = temperature
        self.softmax = nn.Softmax(dim=1)
    def where(self, cond, x_1, x_2):
        cond = cond.type(torch.float32)
        return (cond * x_1) + ((1 - cond) * x_2)
    def forward(self, f1, f2, targets):
        f1 = F.normalize(f1, dim=2)
        f2 = F.normalize(f2, dim=2)
        device = (torch.device('cuda')
                  if features.is_cuda
                  else torch.device('cpu'))

        mask = torch.eye(batch_size, dtype=torch.float32).to(device)

        dist = (f1.unsqueeze(1).unsqueeze(3) - f2.unsqueeze(0)).pow(2).sum(3)
        print(dist.shape)

        exit()


        row_weights = torch.softmax(dist, dim=1)
        row_weights_dist = torch.sum(row_weights * dist, dim=1)
        print(row_weights_dist.shape)



        cos = (1 - 0.5 * dist)
        pred_softmax = F.softmax(cos / self.temperature,dim=1)
        log_pos_softmax = - torch.log(pred_softmax + EPISILON) * mask#biger
        log_neg_softmax = - torch.log(1 - pred_softmax + EPISILON) * self_mask#smaller
        if self_mask.sum() == 0:
            log_softmax = log_pos_softmax.sum(1) / (1 - self_mask).sum(1).float()
        else:
            log_softmax = log_pos_softmax.sum(1) / (1 - self_mask).sum(1).float() + log_neg_softmax.sum(
                1) / self_mask.sum(1).float()
        loss = log_softmax
        return loss.mean()
"""
# 创建 Coarse_SupConLoss 实例
#loss_fn = Coarse_SupConLoss(temperature=0.07, contrast_mode='all')
"""
loss_fn = Coarse_SupConLoss()
# 假设我们有 batch_size = 4, 每个样本有 2 个视图 (n_views = 2)，特征维度为 128
batch_size = 4
n_views = 2
time_dim = 49
feature_dim = 128
torch.manual_seed(111)
# 随机生成特征数据，形状为 [batch_size, n_views, feature_dim]
features = torch.randn(batch_size, n_views, feature_dim)#, time_dim
# 随机生成标签数据，形状为 [batch_size]
labels = torch.tensor([0, 1.0, -2.0, 3.0])
#labels = torch.tensor([3.0, 3.0, 3.0, 3.0])
print(features.shape)
print(labels.shape)
# 计算损失
loss = loss_fn(features[:,0,:], features[:,1,:], labels)#, labels
#loss = loss_fn(features[:,0,:], features[:,1,:], labels)
# 输出损失值
print(f"Loss: {loss.item()}")
exit()
"""


class SupConLoss(nn.Module):
    """Supervised Contrastive Learning: https://arxiv.org/pdf/2004.11362.pdf.
    It also supports the unsupervised contrastive loss in SimCLR"""

    def __init__(self, temperature=0.07, contrast_mode='all'):
        super(SupConLoss, self).__init__()
        self.temperature = temperature
        self.contrast_mode = contrast_mode
        # self.base_temperature = base_temperature

    def forward(self, features, labels=None, mask=None):
        """Compute loss for model. If both `labels` and `mask` are None,
        it degenerates to SimCLR unsupervised loss:
        https://arxiv.org/pdf/2002.05709.pdf
        Args:
            features: hidden vector of shape [bsz, n_views, ...].
            labels: ground truth of shape [bsz].
            mask: contrastive mask of shape [bsz, bsz], mask_{i,j}=1 if sample j
                has the same class as sample i. Can be asymmetric.
        Returns:
            A loss scalar.
        """
        features = torch.nn.functional.normalize(features, p=2, dim=-1)
        device = (torch.device('cuda')
                  if features.is_cuda
                  else torch.device('cpu'))

        if len(features.shape) < 3:
            raise ValueError('`features` needs to be [bsz, n_views, ...],'
                             'at least 3 dimensions are required')
        if len(features.shape) > 3:
            features = features.view(features.shape[0], features.shape[1], -1)

        batch_size = features.shape[0]
        if labels is not None and mask is not None:
            raise ValueError('Cannot define both `labels` and `mask`')
        elif labels is None and mask is None:
            mask = torch.eye(batch_size, dtype=torch.float32).to(device)
        elif labels is not None:
            labels = labels.contiguous().view(-1, 1)
            if labels.shape[0] != batch_size:
                raise ValueError('Num of labels does not match num of features')
            mask = torch.eq(labels, labels.T).float().to(device)

        else:
            mask = mask.float().to(device)

        contrast_count = features.shape[1]  # 2
        contrast_feature = torch.cat(torch.unbind(features, dim=1), dim=0)

        if self.contrast_mode == 'one':
            anchor_feature = features[:, 0]
            anchor_count = 1
        elif self.contrast_mode == 'all':
            anchor_feature = contrast_feature
            anchor_count = contrast_count  # 2
        else:
            raise ValueError('Unknown mode: {}'.format(self.contrast_mode))

        # compute logits
        anchor_dot_contrast = torch.div(
            torch.matmul(anchor_feature, contrast_feature.T),  # 2bs,2bs
            self.temperature)

        logits_max, _ = torch.max(anchor_dot_contrast, dim=1, keepdim=True)
        logits = anchor_dot_contrast - logits_max.detach()

        # tile mask
        mask = mask.repeat(anchor_count, contrast_count)

        # mask-out self-contrast cases
        logits_mask = torch.scatter(
            torch.ones_like(mask),
            1,
            torch.arange(batch_size * anchor_count).view(-1, 1).to(device),
            0
        )  # 2bs,2bs,
        mask = mask * logits_mask
        print(mask.shape)
        # compute log_prob
        exp_logits = torch.exp(logits) * logits_mask
        log_prob = logits - torch.log(exp_logits.sum(1, keepdim=True))
        # log(a/b) = loga - logb

        # compute mean of log-likelihood over positive
        mean_log_prob_pos = (mask * log_prob).sum(1) / mask.sum(1)

        # loss
        # loss = - (self.temperature / self.base_temperature) * mean_log_prob_pos
        loss = -mean_log_prob_pos
        loss = loss.view(anchor_count, batch_size).mean()
        exit()

        return loss


class SupConR1(nn.Module):
    def __init__(self, temperature=0.07):
        super(SupConR1, self).__init__()
        self.temperature = temperature

    def forward(self, features, labels):
        '''
        Args:
            features: hidden vector of shape [bsz, n_views, dim].
            labels: ground truth of shape [bsz].
        Returns:
            A loss scalar.
        '''
        # print(features.shape)

        features = torch.nn.functional.normalize(features, p=2, dim=-1)
        device = (torch.device('cuda')
                  if features.is_cuda
                  else torch.device('cpu'))

        if len(features.shape) < 3:
            raise ValueError('`features` needs to be [bsz, n_views, ...],'
                             'at least 3 dimensions are required')
        if len(features.shape) > 3:
            features = features.view(features.shape[0], features.shape[1], -1)
        # print(features.shape)

        batch_size = features.shape[0]

        contrast_count = features.shape[1]
        contrast_feature = torch.cat(torch.unbind(features, dim=1), dim=0)
        # print(contrast_feature.shape)

        anchor_feature = contrast_feature
        anchor_count = contrast_count
        # print(anchor_count)
        # print(labels.shape)
        labels = labels.squeeze()
        # print(labels)

        distance = torch.abs(labels.unsqueeze(1) - labels.unsqueeze(0))
        # print(labels.unsqueeze(1))
        # print(labels.unsqueeze(0))
        # print(distance)

        mask = distance.unsqueeze(1) - distance.unsqueeze(2)
        mask[mask >= 0] = 1
        mask[mask < 0] = 0
        # print(mask)
        mask = mask.repeat(anchor_count, anchor_count, anchor_count)
        # print(mask)

        diag_mask = torch.eye(batch_size * anchor_count).unsqueeze(1).repeat(1, anchor_count * batch_size,
                                                                             1).bool()  # remove same instance
        # print(diag_mask)
        # print(diag_mask.shape)
        mask.masked_fill_(diag_mask, 0)  # negative=1
        # print(mask)
        # print(mask.shape)
        negative_samples = torch.zeros((batch_size, batch_size, batch_size))

        # compute logits
        anchor_dot_contrast = torch.div(
            torch.matmul(anchor_feature, contrast_feature.T),  # 2bs,2bs
            self.temperature)

        logits_max, _ = torch.max(anchor_dot_contrast, dim=1, keepdim=True)
        # logits = anchor_dot_contrast - logits_max.detach()
        logits = anchor_dot_contrast
        # print(logits)
        # print("z",logits.shape)

        I = torch.eye(batch_size, dtype=torch.float32).to(device)
        # print(I)
        # print(anchor_count, contrast_count)
        I = I.repeat(anchor_count, contrast_count)  # 2N, 2N
        # print(I)

        logits_mask = torch.scatter(
            torch.ones_like(I),
            1,
            torch.arange(batch_size * anchor_count).view(-1, 1).to(device),
            0
        )
        # print(mask)
        # print(logits_mask)
        exp_logits = torch.exp(logits)

        exp_logits = exp_logits.permute(1, 0)

        exp_logits = exp_logits.unsqueeze(0).repeat(contrast_count * batch_size, 1, 1)  # 2N,2N,2N

        negative_samples = exp_logits * mask

        log_prob = logits - torch.log(negative_samples.sum(2))

        # log(a/b) = loga - logb

        # compute mean of log-likelihood over positive
        mean_log_prob_pos = (logits_mask * log_prob).sum(1) / logits_mask.sum(1)
        print(logits_mask)

        loss = -mean_log_prob_pos
        loss = loss.view(anchor_count, batch_size).mean()
        # print(loss)
        exit()
        return loss


class SupConR2(nn.Module):
    def __init__(self, temperature=0.07):
        super(SupConR2, self).__init__()
        self.temperature = temperature

    def forward(self, features, labels):
        '''
        Args:
            features: hidden vector of shape [bsz, n_views, dim].
            labels: ground truth of shape [bsz].
        Returns:
            A loss scalar.
        '''
        # print(features.shape)

        features = torch.nn.functional.normalize(features, p=2, dim=-1)
        device = (torch.device('cuda')
                  if features.is_cuda
                  else torch.device('cpu'))

        if len(features.shape) < 3:
            raise ValueError('`features` needs to be [bsz, n_views, ...],'
                             'at least 3 dimensions are required')
        if len(features.shape) > 3:
            features = features.view(features.shape[0], features.shape[1], -1)
        # print(features.shape)

        batch_size = features.shape[0]

        contrast_count = features.shape[1]
        # contrast_feature = torch.cat(torch.unbind(features, dim=1), dim=0)
        # print(contrast_feature.shape)

        # anchor_feature = contrast_feature
        anchor_feature = torch.unbind(features, dim=1)[0]
        contrast_feature = torch.unbind(features, dim=1)[1]

        anchor_count = contrast_count
        # print(anchor_count)
        # print(labels.shape)
        labels = labels.squeeze()
        # print(labels)

        distance = torch.abs(labels.unsqueeze(1) - labels.unsqueeze(0))
        # print(labels.unsqueeze(1))
        # print(labels.unsqueeze(0))
        # print(distance)

        mask = distance.unsqueeze(1) - distance.unsqueeze(2)
        mask[mask > 0] = 1
        mask[mask <= 0] = 0
        # print(mask)
        # mask = mask.repeat(anchor_count, anchor_count, anchor_count)
        # print(mask)

        diag_mask = torch.eye(batch_size).unsqueeze(1).repeat(1, batch_size,
                                                              1).bool()  # remove same instance
        # print(diag_mask.shape)
        mask.masked_fill_(diag_mask, 0)  # negative=1
        # print(mask)
        # print(mask.shape)
        negative_samples = torch.zeros((batch_size, batch_size, batch_size))

        # compute logits
        anchor_dot_contrast = torch.div(
            torch.matmul(anchor_feature, contrast_feature.T),  # 2bs,2bs
            self.temperature)

        logits_max, _ = torch.max(anchor_dot_contrast, dim=1, keepdim=True)
        # logits = anchor_dot_contrast - logits_max.detach()
        logits = anchor_dot_contrast
        # print(logits)
        # print("z", logits.shape)

        I = torch.eye(batch_size, dtype=torch.float32).to(device)
        # print(I)
        # print(anchor_count, contrast_count)
        # I = I.repeat(anchor_count, contrast_count)  # 2N, 2N
        # print(I)

        logits_mask = torch.scatter(
            torch.ones_like(I),
            1,
            torch.arange(batch_size).view(-1, 1).to(device),
            0
        )
        # print(mask)

        logits_mask = 1 - logits_mask
        exp_logits = torch.exp(logits)

        exp_logits = exp_logits.permute(1, 0)

        exp_logits = exp_logits.unsqueeze(0).repeat(batch_size, 1, 1)  # 2N,2N,2N
        # print(exp_logits.shape)

        negative_samples = exp_logits * mask
        mask_m = 1 - mask

        mask_m.masked_fill_(diag_mask, 0)  # negative=1

        positive_samples = exp_logits * mask_m
        # print((1 - mask))

        log_prob = logits - torch.log(negative_samples.sum(2) + 0.5 * positive_samples.sum(2))

        # log_prob = logits - (torch.log(negative_samples.sum(2)) + torch.log(2 * positive_samples.sum(2)))

        # log(a/b) = loga - logb

        # compute mean of log-likelihood over positive
        mean_log_prob_pos = (logits_mask * log_prob).sum(1) / logits_mask.sum(1)

        loss = -mean_log_prob_pos
        loss = loss.view(batch_size).mean()
        # exit()

        return loss

class SupConRR(nn.Module):  # the same instance and Semantics near
    def __init__(self, temperature=0.07):
        super(SupConRR, self).__init__()
        self.temperature = temperature

    def forward(self, features, labels):
        '''
        Args:
            features: hidden vector of shape [bsz, n_views, dim].
            labels: ground truth of shape [bsz].
        Returns:
            A loss scalar.
        '''
        # print(features.shape)

        features = torch.nn.functional.normalize(features, p=2, dim=-1)
        device = (torch.device('cuda')
                  if features.is_cuda
                  else torch.device('cpu'))

        if len(features.shape) < 3:
            raise ValueError('`features` needs to be [bsz, n_views, ...],'
                             'at least 3 dimensions are required')
        if len(features.shape) > 3:
            features = features.view(features.shape[0], features.shape[1], -1)
        # print(features.shape)

        batch_size = features.shape[0]

        contrast_count = features.shape[1]
        # contrast_feature = torch.cat(torch.unbind(features, dim=1), dim=0)
        # print(contrast_feature.shape)

        # anchor_feature = contrast_feature
        anchor_feature = torch.unbind(features, dim=1)[0]
        contrast_feature = torch.unbind(features, dim=1)[1]

        anchor_count = contrast_count
        # print(anchor_count)
        # print(labels.shape)
        labels = labels.squeeze()
        # print(labels)

        distance = torch.abs(labels.unsqueeze(1) - labels.unsqueeze(0))
        # print(labels.unsqueeze(1))
        # print(labels.unsqueeze(0))
        # print(distance)

        mask = distance.unsqueeze(1) - distance.unsqueeze(2)
        mask[mask >= 0] = 1
        mask[mask < 0] = 0
        # print(mask)
        # mask = mask.repeat(anchor_count, anchor_count, anchor_count)
        # print(mask)

        diag_mask = torch.eye(batch_size).unsqueeze(1).repeat(1, batch_size,
                                                              1).bool().to(device)  # remove same instance
        # print(diag_mask.shape)
        mask.masked_fill_(diag_mask, 0)  # negative=1
        # print(mask)
        # print(mask.shape)
        negative_samples = torch.zeros((batch_size, batch_size, batch_size))

        # compute logits
        anchor_dot_contrast = torch.div(
            torch.matmul(anchor_feature, contrast_feature.T),  # 2bs,2bs
            self.temperature)

        logits_max, _ = torch.max(anchor_dot_contrast, dim=1, keepdim=True)
        # logits = anchor_dot_contrast - logits_max.detach()
        logits = anchor_dot_contrast
        # print(logits)
        # print("z", logits.shape)

        I = torch.eye(batch_size, dtype=torch.float32).to(device)
        # print(I)
        # print(anchor_count, contrast_count)
        # I = I.repeat(anchor_count, contrast_count)  # 2N, 2N
        # print(I)

        # logits_mask = torch.scatter(
        #     torch.ones_like(I),
        #     1,
        #     torch.arange(batch_size).view(-1, 1).to(device),
        #     0
        # )
        logits_mask = torch.scatter(
            torch.ones_like(I),
            1,
            torch.arange(batch_size).view(-1, 1).to(device),
            1
        )
        # print(mask)
        # print(logits_mask)
        exp_logits = torch.exp(logits)
        # print()
        # print(exp_logits)

        exp_logits = exp_logits.permute(1, 0)
        # print(exp_logits)

        exp_logits = exp_logits.unsqueeze(0).repeat(batch_size, 1, 1)  # 2N,2N,2N
        # print(exp_logits.shape)

        negative_samples = exp_logits * mask

        # print(exp_logits)
        # print(negative_samples)
        # print(negative_samples.sum(2))
        # exit()

        mask_m = 1 - mask

        mask_m.masked_fill_(diag_mask, 0)  # negative=1

        positive_samples = exp_logits * mask_m
        # print((1 - mask))

        log_prob = logits - torch.log(negative_samples.sum(2))

        # log_prob = logits - (torch.log(negative_samples.sum(2)) + torch.log(2 * positive_samples.sum(2)))

        # log(a/b) = loga - logb

        # compute mean of log-likelihood over positive
        mean_log_prob_pos = (logits_mask * log_prob).sum(1) / logits_mask.sum(1)

        loss = -mean_log_prob_pos
        loss = loss.view(batch_size).mean()
        # exit()

        return loss

class SupConR(nn.Module):  # the same instance and Semantics near
    def __init__(self, lamda=1.2):
        super(SupConR, self).__init__()
        #self.temperature = temperature
        self.lamda = lamda #/ self.temperature1.2
        #self.norm = 6  # / self.temperature
        # self.using_cuda = len(args.gpu_ids) > 0 and torch.cuda.is_available()
        # self.device = torch.device('cuda:%d' % int(args.gpu_ids[0]) if self.using_cuda else 'cpu')

    def forward(self, features, labels):
        '''
        Args:
            features: hidden vector of shape [bsz, n_views, dim].
            labels: ground truth of shape [bsz].
        Returns:
            A loss scalar.
        '''
        # print(features.shape)

        features = torch.nn.functional.normalize(features, p=2, dim=-1)
        device = (torch.device('cuda')
                  if features.is_cuda
                  else torch.device('cpu'))

        if len(features.shape) < 3:
            raise ValueError('`features` needs to be [bsz, n_views, ...],'
                             'at least 3 dimensions are required')
        if len(features.shape) > 3:
            features = features.view(features.shape[0], features.shape[1], -1)
        # print(features.shape)
        batch_size = features.shape[0]
        #contrast_count = features.shape[1]
        anchor_feature = torch.unbind(features, dim=1)[0]
        contrast_feature = torch.unbind(features, dim=1)[1]
        # anchor_feature = anchor_feature.contiguous()
        # contrast_feature = contrast_feature.contiguous()
        #anchor_count = contrast_count
        labels = labels.squeeze()
        distance = torch.abs(labels.unsqueeze(1) - labels.unsqueeze(0))
        #norm_distance = distance/self.norm
        mask = distance.unsqueeze(1) - distance.unsqueeze(2)
        mask[mask >= 0] = 1
        mask[mask < 0] = 0


        diag_mask = torch.eye(batch_size).unsqueeze(1).repeat(1, batch_size,
                                                              1).bool().to(device)  # remove same instance
        # print(diag_mask.shape)
        mask.masked_fill_(diag_mask, 0)  # negative=1
        # compute logits
        #anchor_dot_contrast = torch.cdist(anchor_feature, contrast_feature, p=2)
        #anchor_dot_contrast = torch.norm(anchor_feature.unsqueeze(1) - contrast_feature.unsqueeze(0), p=2, dim=-1)
        anchor_dot_contrast = torch.norm(contrast_feature.unsqueeze(1) - anchor_feature.unsqueeze(0), p=2, dim=-1)


        logits = anchor_dot_contrast
        I = torch.eye(batch_size, dtype=torch.float32).to(device)

        logits_mask = torch.scatter(
            torch.ones_like(I),
            1,
            torch.arange(batch_size).view(-1, 1).to(device),
            1
        )
        exp_logits = logits.permute(1, 0)
        exp_logits = exp_logits.unsqueeze(0).repeat(batch_size, 1, 1)  # 2N,2N,2N
        #neg_norm_distance = norm_distance.permute(1, 0)
        #neg_norm_distance = neg_norm_distance.unsqueeze(0).repeat(batch_size, 1, 1)  # 2N,2N,2N
        negative_samples = exp_logits * mask
        #neg_norm_distance = neg_norm_distance * mask
        #log_prob = logits**2 + torch.relu(self.lamda - negative_samples.sum(2))**2
        #log_prob = (1 - norm_distance) * logits**2 + (1 - norm_distance) * ((torch.relu(self.lamda * (1 - neg_norm_distance) - negative_samples)**2).sum(2))
        # log_prob = (1 - norm_distance) * logits ** 2 + ((1 - neg_norm_distance) * mask * (
        #         torch.relu(self.lamda * neg_norm_distance - negative_samples) ** 2)).sum(2)
        log_prob = logits ** 2 + (F.relu(mask * self.lamda - negative_samples) ** 2).mean(2)#XXXXXXXXXXXXXXXXXXX
        #log_prob = logits + (torch.relu(mask * self.lamda - negative_samples)).mean(2)  # XXXXXXXXXXXXXXXXXXX
        #log_prob = logits + (torch.relu(mask * (self.lamda - negative_samples))).sum(2)
        #log_prob = logits ** 2 + (torch.relu(mask * self.lamda - mask * negative_samples) ** 2).mean(2)

        # log_prob = logits + torch.relu(mask * (self.lamda - negative_samples)).sum(2)
        #log_prob = logits ** 2 + torch.relu(self.lamda - negative_samples.sum(2)) ** 2

        #log_prob = logits + torch.abs(torch.relu(self.lamda - negative_samples.sum(2)))# ** 2
        #log_prob = logits + torch.relu(torch.abs(self.lamda - negative_samples.sum(2)))  # ** 2
        #log_prob = logits + torch.relu(self.lamda - negative_samples.sum(2))  # ** 2
        #mean_log_prob_pos = (logits_mask * log_prob).sum(1) / logits_mask.sum(1)
        mean_log_prob_pos = (logits_mask * log_prob).sum(0) / logits_mask.sum(0)
        loss = mean_log_prob_pos
        loss = loss.view(batch_size).mean()
        # exit()

        return loss
class SamCon(nn.Module):  # the same instance and Semantics near
    def __init__(self, lamda = 1.2):
        super(SamCon, self).__init__()
        self.lamda = lamda #/ self.temperature1.2
        #self.norm = 6  # / self.temperature
        # self.using_cuda = len(args.gpu_ids) > 0 and torch.cuda.is_available()
        # self.device = torch.device('cuda:%d' % int(args.gpu_ids[0]) if self.using_cuda else 'cpu')

    def forward(self, features, labels):
        '''
        Args:
            features: hidden vector of shape [bsz, n_views, dim].
            labels: ground truth of shape [bsz].
        Returns:
            A loss scalar.
        '''
        # print(features.shape)

        features = torch.nn.functional.normalize(features, p=2, dim=-1)
        device = (torch.device('cuda')
                  if features.is_cuda
                  else torch.device('cpu'))

        if len(features.shape) < 3:
            raise ValueError('`features` needs to be [bsz, n_views, ...],'
                             'at least 3 dimensions are required')
        if len(features.shape) > 3:
            features = features.view(features.shape[0], features.shape[1], -1)
        # print(features.shape)
        batch_size = features.shape[0]
        #contrast_count = features.shape[1]
        anchor_feature = torch.unbind(features, dim=1)[0]
        contrast_feature = torch.unbind(features, dim=1)[1]
        mask = torch.eye(batch_size, dtype=torch.float32).to(device)
        mask_negative = 1 - mask
        anchor_dot_contrast = torch.norm(contrast_feature.unsqueeze(1) - anchor_feature.unsqueeze(0), p=2, dim=-1)
        logits = anchor_dot_contrast * mask
        negative_logits = anchor_dot_contrast * mask_negative
        log_prob = (logits ** 2).sum(1) + (torch.relu(self.lamda - negative_logits) ** 2).sum(1)
        mean_log_prob_pos = (log_prob) / mask.sum(1)
        loss = mean_log_prob_pos
        loss = loss.view(batch_size).mean()
        return loss
class AdSamCon(nn.Module):  # the same instance and Semantics near
    def __init__(self, lamda = 1.2, temperature= 0.7, alpha= 1):
        super(AdSamCon, self).__init__()
        self.temperature = temperature
        self.alpha = alpha
        self.lamda = lamda #/ self.temperature1.2
        #self.norm = 6  # / self.temperature
        # self.using_cuda = len(args.gpu_ids) > 0 and torch.cuda.is_available()
        # self.device = torch.device('cuda:%d' % int(args.gpu_ids[0]) if self.using_cuda else 'cpu')

    def forward(self, features, pred, pred_m, target):
        '''
        Args:
            features: hidden vector of shape [bsz, n_views, dim].
            labels: ground truth of shape [bsz].
        Returns:
            A loss scalar.
        '''
        # print(features.shape)

        features = torch.nn.functional.normalize(features, p=2, dim=-1)
        device = (torch.device('cuda')
                  if features.is_cuda
                  else torch.device('cpu'))

        if len(features.shape) < 3:
            raise ValueError('`features` needs to be [bsz, n_views, ...],'
                             'at least 3 dimensions are required')
        if len(features.shape) > 3:
            features = features.view(features.shape[0], features.shape[1], -1)
        # print(features.shape)
        batch_size = features.shape[0]
        #contrast_count = features.shape[1]
        anchor_feature = torch.unbind(features, dim=1)[0]
        contrast_feature = torch.unbind(features, dim=1)[1]
        mask = torch.eye(batch_size, dtype=torch.float32).to(device)
        mask_negative = 1 - mask
        anchor_dot_contrast = torch.norm(contrast_feature.unsqueeze(1) - anchor_feature.unsqueeze(0), p=2, dim=-1)
        logits = anchor_dot_contrast * mask
        #negative_logits = anchor_dot_contrast * mask_negative


        #log_prob = (logits ** 2).sum(1) + (torch.relu((self.lamda - negative_logits)) ** 2).sum(1)#mask_negative *
        #log_prob = (logits ** 2).sum(1) #+ (torch.relu(mask_negative * (self.lamda - anchor_dot_contrast)) ** 2).sum(1)  # mask_negative *
        #log_prob = (logits ** 2).sum(1) + (torch.relu(((mask_negative * self.lamda - negative_logits)).sum(1)) ** 2)
        log_prob = (logits ** 2).sum(1) + (F.relu(mask_negative * (self.lamda - anchor_dot_contrast)) ** 2).sum(1)#mask_negative *
        erro = torch.abs(pred_m - target) - torch.abs(pred - target)

        #x_min = erro.min(dim=0, keepdim=True).values
        #x_max = erro.max(dim=0, keepdim=True).values
        # 实现 Min-Max Normalization
        ##x_normalized = (erro - x_min) / (x_max - x_min)

        #log_prob = (2 * self.alpha * torch.sigmoid(torch.div(-x_normalized, self.temperature))) * log_prob
        #log_prob = (2 * self.alpha * (torch.sigmoid(torch.div(-erro, self.temperature))-0.5)) * log_prob
        #log_prob = (self.alpha * torch.sigmoid(torch.div(erro, self.temperature))) * log_prob

        #log_prob = self.alpha * torch.relu(torch.sigmoid(torch.div(erro, self.temperature)) - 0.5) * log_prob
        #log_prob = self.alpha * F.relu(torch.div(erro, self.temperature)) * log_prob
        #print(torch.tanh(erro))
        #log_prob = self.alpha * torch.relu(erro) * log_prob
        #print((self.alpha * torch.relu(torch.div(erro, self.temperature))).shape)
        #print(torch.relu(torch.div(erro, self.temperature)))

        mean_log_prob_pos = (log_prob) / mask.sum(1)
        loss = mean_log_prob_pos
        loss = loss.view(batch_size).mean()
        return loss
class AdSamConc(nn.Module):  # the same instance and Semantics near
    def __init__(self, lamda = 1.2, temperature= 0.7, alpha= 1):
        super(AdSamConc, self).__init__()
        self.temperature = temperature
        self.alpha = alpha
        self.lamda = lamda #/ self.temperature1.2
        #self.norm = 6  # / self.temperature
        # self.using_cuda = len(args.gpu_ids) > 0 and torch.cuda.is_available()
        # self.device = torch.device('cuda:%d' % int(args.gpu_ids[0]) if self.using_cuda else 'cpu')

    def forward(self, features, pred, target):
        '''
        Args:
            features: hidden vector of shape [bsz, n_views, dim].
            labels: ground truth of shape [bsz].
        Returns:
            A loss scalar.
        '''
        # print(features.shape)

        features = torch.nn.functional.normalize(features, p=2, dim=-1)
        device = (torch.device('cuda')
                  if features.is_cuda
                  else torch.device('cpu'))

        if len(features.shape) < 3:
            raise ValueError('`features` needs to be [bsz, n_views, ...],'
                             'at least 3 dimensions are required')
        if len(features.shape) > 3:
            features = features.view(features.shape[0], features.shape[1], -1)
        # print(features.shape)
        batch_size = features.shape[0]
        #contrast_count = features.shape[1]
        anchor_feature = torch.unbind(features, dim=1)[0]
        contrast_feature = torch.unbind(features, dim=1)[1]
        mask = torch.eye(batch_size, dtype=torch.float32).to(device)
        mask_negative = 1 - mask
        anchor_dot_contrast = torch.norm(contrast_feature.unsqueeze(1) - anchor_feature.unsqueeze(0), p=2, dim=-1)
        logits = anchor_dot_contrast * mask
        negative_logits = anchor_dot_contrast * mask_negative

        # x_min = torch.abs(pred - target).min(dim=0, keepdim=True).values
        # x_max = torch.abs(pred - target).max(dim=0, keepdim=True).values
        # # 实现 Min-Max Normalization
        # x_normalized = (torch.abs(pred - target) - x_min) / (x_max - x_min)
        log_prob = (logits ** 2).sum(1) + (torch.relu(self.lamda - negative_logits) ** 2).sum(1)

        log_prob = (2 * self.alpha * torch.sigmoid(torch.div(-torch.abs(pred - target), self.temperature))) * log_prob

        mean_log_prob_pos = (log_prob) / mask.sum(1)
        loss = mean_log_prob_pos
        loss = loss.view(batch_size).mean()
        return loss
class SupConR16(nn.Module):  # the same instance and Semantics near
    def __init__(self, temperature=0.07):
        super(SupConR16, self).__init__()
        self.temperature = temperature
        self.lamda = 1.4 #/ self.temperature
        # self.using_cuda = len(args.gpu_ids) > 0 and torch.cuda.is_available()
        # self.device = torch.device('cuda:%d' % int(args.gpu_ids[0]) if self.using_cuda else 'cpu')

    def forward(self, features, labels):
        '''
        Args:
            features: hidden vector of shape [bsz, n_views, dim].
            labels: ground truth of shape [bsz].
        Returns:
            A loss scalar.
        '''
        # print(features.shape)

        features = torch.nn.functional.normalize(features, p=2, dim=-1)
        device = (torch.device('cuda')
                  if features.is_cuda
                  else torch.device('cpu'))

        if len(features.shape) < 3:
            raise ValueError('`features` needs to be [bsz, n_views, ...],'
                             'at least 3 dimensions are required')
        if len(features.shape) > 3:
            features = features.view(features.shape[0], features.shape[1], -1)
        # print(features.shape)
        batch_size = features.shape[0]
        contrast_count = features.shape[1]
        anchor_feature = torch.unbind(features, dim=1)[0]
        contrast_feature = torch.unbind(features, dim=1)[1]
        anchor_count = contrast_count
        labels = labels.squeeze()

        distance = torch.abs(labels.unsqueeze(1) - labels.unsqueeze(0))


        mask = distance.unsqueeze(1) - distance.unsqueeze(2)
        mask[mask >= 0] = 1
        mask[mask < 0] = 0


        diag_mask = torch.eye(batch_size).unsqueeze(1).repeat(1, batch_size,
                                                              1).bool().to(device)  # remove same instance
        # print(diag_mask.shape)
        mask.masked_fill_(diag_mask, 0)  # negative=1
        # print(mask)
        # print(mask.shape)
        negative_samples = torch.zeros((batch_size, batch_size, batch_size))

        # compute logits
        #anchor_dot_contrast = torch.cdist(anchor_feature, contrast_feature, p=2)
        anchor_dot_contrast = torch.norm(anchor_feature.unsqueeze(1) - contrast_feature.unsqueeze(0), p=2, dim=-1)
        logits = anchor_dot_contrast ** 2
        I = torch.eye(batch_size, dtype=torch.float32).to(device)

        logits_mask = torch.scatter(
            torch.ones_like(I),
            1,
            torch.arange(batch_size).view(-1, 1).to(device),
            1
        )
        exp_logits = logits.permute(1, 0)
        exp_logits = exp_logits.unsqueeze(0).repeat(batch_size, 1, 1)  # 2N,2N,2N
        negative_samples = exp_logits * mask

        mask_m = 1 - mask

        mask_m.masked_fill_(diag_mask, 0)  # negative=1
        log_prob = logits ** 2 + torch.relu(self.lamda - negative_samples.sum(2)) ** 2
        #log_prob = logits**2 + torch.relu(self.lamda - negative_samples.sum(2))**2
        #log_prob = logits + torch.abs(torch.relu(self.lamda - negative_samples.sum(2)))# ** 2
        #log_prob = logits + torch.relu(self.lamda - negative_samples.sum(2))  # ** 2
        #log_prob = logits + torch.relu(torch.abs(self.lamda - negative_samples.sum(2)))  # ** 2
        #log_prob = logits**2 + (torch.relu((self.lamda - negative_samples))**2).sum(2)
        #log_prob = logits + torch.relu(self.lamda - negative_samples.sum(2))
        #log_prob = logits + torch.relu(self.lamda - negative_samples.sum(2))
        mean_log_prob_pos = (logits_mask * log_prob).sum(1) / logits_mask.sum(1)
        loss = mean_log_prob_pos
        loss = loss.view(batch_size).mean()
        # exit()

        return loss
class SupConRcos(nn.Module):  # the same instance and Semantics near cos
    def __init__(self, temperature=0.07):
        super(SupConRcos, self).__init__()
        self.temperature = temperature
        self.lamda = 1 #/ self.temperature
        # self.using_cuda = len(args.gpu_ids) > 0 and torch.cuda.is_available()
        # self.device = torch.device('cuda:%d' % int(args.gpu_ids[0]) if self.using_cuda else 'cpu')

    def forward(self, features, labels):
        '''
        Args:
            features: hidden vector of shape [bsz, n_views, dim].
            labels: ground truth of shape [bsz].
        Returns:
            A loss scalar.
        '''
        # print(features.shape)

        features = torch.nn.functional.normalize(features, p=2, dim=-1)
        device = (torch.device('cuda')
                  if features.is_cuda
                  else torch.device('cpu'))

        if len(features.shape) < 3:
            raise ValueError('`features` needs to be [bsz, n_views, ...],'
                             'at least 3 dimensions are required')
        if len(features.shape) > 3:
            features = features.view(features.shape[0], features.shape[1], -1)
        # print(features.shape)
        batch_size = features.shape[0]
        contrast_count = features.shape[1]
        anchor_feature = torch.unbind(features, dim=1)[0]
        contrast_feature = torch.unbind(features, dim=1)[1]
        # anchor_feature = anchor_feature.contiguous()
        # contrast_feature = contrast_feature.contiguous()
        anchor_count = contrast_count
        labels = labels.squeeze()

        distance = torch.abs(labels.unsqueeze(1) - labels.unsqueeze(0))


        mask = distance.unsqueeze(1) - distance.unsqueeze(2)
        mask[mask >= 0] = 1
        mask[mask < 0] = 0


        diag_mask = torch.eye(batch_size).unsqueeze(1).repeat(1, batch_size,
                                                              1).bool().to(device)  # remove same instance
        # print(diag_mask.shape)
        mask.masked_fill_(diag_mask, 0)  # negative=1
        # compute logits
        #anchor_dot_contrast = torch.cdist(anchor_feature, contrast_feature, p=2)
        #anchor_dot_contrast = torch.norm(anchor_feature.unsqueeze(1) - contrast_feature.unsqueeze(0), p=2, dim=-1)
        anchor_dot_contrast = torch.div(
            torch.matmul(anchor_feature, contrast_feature.T),  # 2bs,2bs
            self.temperature)


        logits = anchor_dot_contrast
        I = torch.eye(batch_size, dtype=torch.float32).to(device)

        logits_mask = torch.scatter(
            torch.ones_like(I),
            1,
            torch.arange(batch_size).view(-1, 1).to(device),
            1
        )
        exp_logits = logits.permute(1, 0)
        exp_logits = exp_logits.unsqueeze(0).repeat(batch_size, 1, 1)  # 2N,2N,2N
        negative_samples = exp_logits * mask

        mask_m = 1 - mask

        mask_m.masked_fill_(diag_mask, 0)  # negative=1
        log_prob = torch.relu(self.lamda - logits) + negative_samples.sum(2)
        #log_prob = logits + torch.abs(torch.relu(self.lamda - negative_samples.sum(2)))# ** 2
        #log_prob = logits + torch.relu(torch.abs(self.lamda - negative_samples.sum(2)))  # ** 2
        #log_prob = logits + torch.relu(self.lamda - negative_samples.sum(2))  # ** 2
        mean_log_prob_pos = (logits_mask * log_prob).sum(1) / logits_mask.sum(1)
        loss = mean_log_prob_pos
        loss = loss.view(batch_size).mean()
        # exit()

        return loss

class SupConR17(nn.Module):  # the same instance and Semantics near
    def __init__(self, temperature=0.07):
        super(SupConR17, self).__init__()
        self.temperature = temperature
        self.lamda = 1.4 #/ self.temperature
        # self.using_cuda = len(args.gpu_ids) > 0 and torch.cuda.is_available()
        # self.device = torch.device('cuda:%d' % int(args.gpu_ids[0]) if self.using_cuda else 'cpu')

    def forward(self, features, labels):
        '''
        Args:
            features: hidden vector of shape [bsz, n_views, dim].
            labels: ground truth of shape [bsz].
        Returns:
            A loss scalar.
        '''
        # print(features.shape)

        features = torch.nn.functional.normalize(features, p=2, dim=-1)
        device = (torch.device('cuda')
                  if features.is_cuda
                  else torch.device('cpu'))

        if len(features.shape) < 3:
            raise ValueError('`features` needs to be [bsz, n_views, ...],'
                             'at least 3 dimensions are required')
        if len(features.shape) > 3:
            features = features.view(features.shape[0], features.shape[1], -1)
        # print(features.shape)
        batch_size = features.shape[0]
        contrast_count = features.shape[1]
        anchor_feature = torch.unbind(features, dim=1)[0]
        contrast_feature = torch.unbind(features, dim=1)[1]
        # anchor_feature = anchor_feature.contiguous()
        # contrast_feature = contrast_feature.contiguous()
        anchor_count = contrast_count
        labels = labels.squeeze()

        distance = torch.abs(labels.unsqueeze(1) - labels.unsqueeze(0))


        mask = distance.unsqueeze(1) - distance.unsqueeze(2)
        mask[mask >= 0] = 1
        mask[mask < 0] = 0


        diag_mask = torch.eye(batch_size).unsqueeze(1).repeat(1, batch_size,
                                                              1).bool().to(device)  # remove same instance
        # print(diag_mask.shape)
        mask.masked_fill_(diag_mask, 0)  # negative=1
        # compute logits
        #anchor_dot_contrast = torch.cdist(anchor_feature, contrast_feature, p=2)
        anchor_dot_contrast = torch.norm(anchor_feature.unsqueeze(1) - contrast_feature.unsqueeze(0), p=2, dim=-1)


        logits = anchor_dot_contrast
        I = torch.eye(batch_size, dtype=torch.float32).to(device)

        logits_mask = torch.scatter(
            torch.ones_like(I),
            1,
            torch.arange(batch_size).view(-1, 1).to(device),
            1
        )
        #exp_logits = torch.exp(logits)
        exp_logits = logits.permute(1, 0)
        exp_logits = exp_logits.unsqueeze(0).repeat(batch_size, 1, 1)  # 2N,2N,2N
        negative_samples = exp_logits * mask

        mask_m = 1 - mask

        mask_m.masked_fill_(diag_mask, 0)  # negative=1
        #log_prob = torch.log(torch.exp(logits**2) + torch.exp(torch.relu(self.lamda - negative_samples.sum(2))**2))
        #log_prob = torch.log(torch.exp(logits) + torch.exp(torch.relu(self.lamda - negative_samples.sum(2))))
        log_prob = logits + torch.log(torch.exp(torch.relu(self.lamda - negative_samples.sum(2))))
        #log_prob = logits + torch.abs(torch.relu(self.lamda - negative_samples.sum(2)))# ** 2
        #log_prob = logits + torch.relu(torch.abs(self.lamda - negative_samples.sum(2)))  # ** 2
        #log_prob = logits + torch.relu(self.lamda - negative_samples.sum(2))  # ** 2
        mean_log_prob_pos = (logits_mask * log_prob).sum(1) / logits_mask.sum(1)
        loss = mean_log_prob_pos
        loss = loss.view(batch_size).mean()
        # exit()

        return loss

class SupConR18(nn.Module):  # the same instance and Semantics near
    def __init__(self, temperature=0.07):
        super(SupConR18, self).__init__()
        self.temperature = temperature
        self.lamda = 0.8 #/ self.temperature
        # self.using_cuda = len(args.gpu_ids) > 0 and torch.cuda.is_available()
        # self.device = torch.device('cuda:%d' % int(args.gpu_ids[0]) if self.using_cuda else 'cpu')

    def forward(self, features, labels):
        '''
        Args:
            features: hidden vector of shape [bsz, n_views, dim].
            labels: ground truth of shape [bsz].
        Returns:
            A loss scalar.
        '''
        # print(features.shape)

        features = torch.nn.functional.normalize(features, p=2, dim=-1)
        device = (torch.device('cuda')
                  if features.is_cuda
                  else torch.device('cpu'))

        if len(features.shape) < 3:
            raise ValueError('`features` needs to be [bsz, n_views, ...],'
                             'at least 3 dimensions are required')
        if len(features.shape) > 3:
            features = features.view(features.shape[0], features.shape[1], -1)
        # print(features.shape)
        batch_size = features.shape[0]
        contrast_count = features.shape[1]
        anchor_feature = torch.unbind(features, dim=1)[0]
        contrast_feature = torch.unbind(features, dim=1)[1]
        # anchor_feature = anchor_feature.contiguous()
        # contrast_feature = contrast_feature.contiguous()
        anchor_count = contrast_count
        labels = labels.squeeze()

        distance = torch.abs(labels.unsqueeze(1) - labels.unsqueeze(0))


        mask = distance.unsqueeze(1) - distance.unsqueeze(2)
        mask[mask >= 0] = 1
        mask[mask < 0] = 0


        diag_mask = torch.eye(batch_size).unsqueeze(1).repeat(1, batch_size,
                                                              1).bool().to(device)  # remove same instance
        # print(diag_mask.shape)
        mask.masked_fill_(diag_mask, 0)  # negative=1
        # compute logits
        #anchor_dot_contrast = torch.cdist(anchor_feature, contrast_feature, p=2)
        #anchor_dot_contrast = torch.norm(contrast_feature.unsqueeze(1) - anchor_feature.unsqueeze(0), p=2, dim=-1)
        anchor_dot_contrast = torch.norm(anchor_feature.unsqueeze(1) - contrast_feature.unsqueeze(0), p=2, dim=-1)


        logits = anchor_dot_contrast
        I = torch.eye(batch_size, dtype=torch.float32).to(device)

        logits_mask = torch.scatter(
            torch.ones_like(I),
            1,
            torch.arange(batch_size).view(-1, 1).to(device),
            1
        )
        exp_logits = logits#.permute(1, 0)
        # print(exp_logits)
        # exit()
        exp_logits = exp_logits.unsqueeze(0).repeat(batch_size, 1, 1)  # 2N,2N,2N
        negative_samples = exp_logits * mask
        mask_m = 1 - mask

        mask_m.masked_fill_(diag_mask, 0)  # negative=1
        log_prob = logits**2 + torch.relu(self.lamda - negative_samples.sum(2))**2
        #log_prob = logits + torch.abs(torch.relu(self.lamda - negative_samples.sum(2)))# ** 2
        #log_prob = logits + torch.relu(torch.abs(self.lamda - negative_samples.sum(2)))  # ** 2
        #log_prob = logits + torch.relu(self.lamda - negative_samples.sum(2))  # ** 2
        mean_log_prob_pos = (logits_mask * log_prob).sum(1) / logits_mask.sum(1)
        loss = mean_log_prob_pos
        loss = loss.view(batch_size).mean()
        # exit()

        return loss

class Similarity(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, features):
        simlarity = torch.norm(features[:, 0, :] - features[:, 1, :], p=2, dim=1)
        return simlarity.mean()

class MultVariateKLD(torch.nn.Module):
    def __init__(self, reduction='mean'):
        super(MultVariateKLD, self).__init__()
        self.reduction = reduction
        #self.args = args
    def forward(self, m1, m2): # var is standard deviation
        assert len(m1.shape) == 3 and len(m2.shape) == 3, \
            'Features should have shape(bs, len, d) not ' + str(m1.shape)
        # m1 = torch.relu(m1)
        # m2 = torch.relu(m2)

        var_m1, var_m2 = m1.var(dim=-1), m2.var(dim=-1)
        m1_, m2_ = m1.mean(-1), m2.mean(-1)
        mu1, mu2 = var_m1.type(dtype=torch.float64), var_m2.type(dtype=torch.float64)
        sigma_1 = m1_.type(dtype=torch.float64)
        sigma_2 = m2_.type(dtype=torch.float64)
        #print(sigma_1[0])

        sigma_diag_1 = torch.diag_embed(sigma_1, offset=0, dim1=-2, dim2=-1)#协方差矩阵
        #print(sigma_diag_1[0])
        sigma_diag_2 = torch.diag_embed(sigma_2, offset=0, dim1=-2, dim2=-1)

        sigma_diag_2_inv = sigma_diag_2.inverse()
        #sigma_diag_2_inv = torch.inverse(sigma_diag_2.to('cpu')).to(self.args.device)
        #print(sigma_diag_2_inv.shape)

        # log(det(sigma2^T)/det(sigma1))
        term_1 = (sigma_diag_2.det() / sigma_diag_1.det()).log()
        # trace(inv(sigma2)*sigma1)
        term_2 = torch.diagonal((torch.matmul(sigma_diag_2_inv, sigma_diag_1)), dim1=-2, dim2=-1).sum(-1)

        # (mu2-m1)^T*inv(sigma2)*(mu2-mu1)
        term_3 = torch.matmul(torch.matmul((mu2 - mu1).unsqueeze(-1).transpose(2, 1), sigma_diag_2_inv),
                              (mu2 - mu1).unsqueeze(-1)).flatten()

        # dimension of embedded space (number of mus and sigmas)
        n = mu1.shape[1]

        # Calc kl divergence on entire batch
        kl = 0.5 * (term_1 - n + term_2 + term_3)
        # print("term_1",term_1)
        # print("term_2",term_2)
        # print("term_3",term_3)
        # print("term_4",n)
        # exit()
        #print(kl.shape)

        # Calculate mean kl_d loss
        if self.reduction == 'mean':
            kl_agg = torch.mean(kl)
        elif self.reduction == 'sum':
            kl_agg = torch.sum(kl)
        else:
            raise NotImplementedError(f'Reduction type not implemented: {self.reduction}')

        return kl_agg

class CMD(nn.Module):
    """
    Adapted from https://github.com/wzell/cmd/blob/master/models/domain_regularizer.py
    """

    def __init__(self):
        super(CMD, self).__init__()

    def forward(self, x1, x2, n_moments=5):
        mx1 = torch.mean(x1, 0)
        mx2 = torch.mean(x2, 0)
        #print(mx1.shape)
        sx1 = x1-mx1
        sx2 = x2-mx2
        dm = self.matchnorm(mx1, mx2)
        scms = dm
        for i in range(n_moments - 1):
            scms += self.scm(sx1, sx2, i + 2)
        return scms

    def matchnorm(self, x1, x2):
        power = torch.pow(x1-x2,2)
        summed = torch.sum(power)
        sqrt = summed**(0.5)
        return sqrt
        # return ((x1-x2)**2).sum().sqrt()

    def scm(self, sx1, sx2, k):
        ss1 = torch.mean(torch.pow(sx1, k), 0)

        ss2 = torch.mean(torch.pow(sx2, k), 0)
        return self.matchnorm(ss1, ss2)

class ReconLoss(nn.Module):
    def __init__(self, type):
        super().__init__()
        self.eps = 1e-6
        self.type = type
        if type == 'L1Loss':
            self.loss = nn.L1Loss(reduction='sum')
        elif type == 'SmoothL1Loss':
            self.loss = nn.SmoothL1Loss(reduction='sum')
        elif type == 'MSELoss':
            self.loss = nn.MSELoss(reduction='sum')
        else:
            raise NotImplementedError

    def forward(self, pred, target, mask):
        """
            pred, target -> batch, seq_len, d
            mask -> batch, seq_len
        """
        mask = mask.unsqueeze(-1).expand(pred.shape[0], pred.shape[1], pred.shape[2]).float()

        loss = self.loss(pred*mask, target*mask) / (torch.sum(mask) + self.eps)

        return loss

class AdSamCon(nn.Module):  # the same instance and Semantics near
    def __init__(self, lamda = 1.2, temperature= 0.7, alpha= 1):
        super(AdSamCon, self).__init__()
        self.temperature = temperature
        self.alpha = alpha
        self.lamda = lamda #/ self.temperature1.2
        #self.norm = 6  # / self.temperature
        # self.using_cuda = len(args.gpu_ids) > 0 and torch.cuda.is_available()
        # self.device = torch.device('cuda:%d' % int(args.gpu_ids[0]) if self.using_cuda else 'cpu')

    def forward(self, features, pred, pred_m, target):
        '''
        Args:
            features: hidden vector of shape [bsz, n_views, dim].
            labels: ground truth of shape [bsz].
        Returns:
            A loss scalar.
        '''
        # print(features.shape)

        features = torch.nn.functional.normalize(features, p=2, dim=-1)
        device = (torch.device('cuda')
                  if features.is_cuda
                  else torch.device('cpu'))

        if len(features.shape) < 3:
            raise ValueError('`features` needs to be [bsz, n_views, ...],'
                             'at least 3 dimensions are required')
        if len(features.shape) > 3:
            features = features.view(features.shape[0], features.shape[1], -1)
        # print(features.shape)
        batch_size = features.shape[0]
        #contrast_count = features.shape[1]
        anchor_feature = torch.unbind(features, dim=1)[0]
        contrast_feature = torch.unbind(features, dim=1)[1]
        mask = torch.eye(batch_size, dtype=torch.float32).to(device)
        mask_negative = 1 - mask
        anchor_dot_contrast = torch.norm(contrast_feature.unsqueeze(1) - anchor_feature.unsqueeze(0), p=2, dim=-1)
        logits = anchor_dot_contrast * mask
        #negative_logits = anchor_dot_contrast * mask_negative


        #log_prob = (logits ** 2).sum(1) + (torch.relu((self.lamda - negative_logits)) ** 2).sum(1)#mask_negative *
        #log_prob = (logits ** 2).sum(1) #+ (torch.relu(mask_negative * (self.lamda - anchor_dot_contrast)) ** 2).sum(1)  # mask_negative *
        #log_prob = (logits ** 2).sum(1) + (torch.relu(((mask_negative * self.lamda - negative_logits)).sum(1)) ** 2)
        log_prob = (logits ** 2).sum(1) + (F.relu(mask_negative * (self.lamda - anchor_dot_contrast)) ** 2).sum(1)#mask_negative *
        #erro = torch.abs(pred_m - target) - torch.abs(pred - target)

        #x_min = erro.min(dim=0, keepdim=True).values
        #x_max = erro.max(dim=0, keepdim=True).values
        # 实现 Min-Max Normalization
        ##x_normalized = (erro - x_min) / (x_max - x_min)

        #log_prob = (2 * self.alpha * torch.sigmoid(torch.div(-x_normalized, self.temperature))) * log_prob
        #log_prob = (2 * self.alpha * (torch.sigmoid(torch.div(-erro, self.temperature))-0.5)) * log_prob
        #log_prob = (self.alpha * torch.sigmoid(torch.div(erro, self.temperature))) * log_prob

        #log_prob = self.alpha * torch.relu(torch.sigmoid(torch.div(erro, self.temperature)) - 0.5) * log_prob
        #log_prob = self.alpha * F.relu(torch.div(erro, self.temperature)) * log_prob
        #print(torch.tanh(erro))
        #log_prob = self.alpha * torch.relu(erro) * log_prob
        #print((self.alpha * torch.relu(torch.div(erro, self.temperature))).shape)
        #print(torch.relu(torch.div(erro, self.temperature)))

        mean_log_prob_pos = (log_prob) / mask.sum(1)
        loss = mean_log_prob_pos
        loss = loss.view(batch_size).mean()
        return loss


def contralLoss(representations, label, temperature=0.1):
    T = temperature
    label = label
    n = label.shape[0]
    representations = representations
    similarity_matrix = F.cosine_similarity(representations.unsqueeze(1), representations.unsqueeze(0), dim=2)
    mask = torch.ones_like(similarity_matrix) * (label.expand(n, n).eq(label.expand(n, n).t()))
    mask_no_sim = torch.ones_like(mask) - mask
    mask_dui_jiao_0 = torch.ones(n ,n) - torch.eye(n, n )
    similarity_matrix = torch.exp(similarity_matrix/T)
    similarity_matrix = similarity_matrix*mask_dui_jiao_0.to(device='cuda')
    sim = mask*similarity_matrix
    no_sim = similarity_matrix - sim
    no_sim_sum = torch.sum(no_sim , dim=1)
    no_sim_sum_expend = no_sim_sum.repeat(n, 1).T
    sim_sum  = sim + no_sim_sum_expend
    loss = torch.div(sim , sim_sum)
    loss = mask_no_sim.to(device='cuda') + loss.to(device='cuda') + torch.eye(n, n ).to(device='cuda')
    loss = -torch.log(loss)
    loss = torch.sum(torch.sum(loss, dim=1)) / (len(torch.nonzero(loss)))
    return loss