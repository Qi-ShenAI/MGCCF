import os
import time
import logging
import math
import copy
import argparse
import numpy as np
import pickle as plk
from glob import glob
from tqdm import tqdm
import time

import torch
import torch.nn as nn
from torch import optim
import torch.nn.functional as F
from utils.functions import dict_to_str
from utils.metricsTop import MetricsTop
from trains.singleTask.Loss import IBLoss, Fine_ConLoss, Coarse_SupConLoss, SupConR, Similarity, SupConLoss, SamCon, AdSamCon, MultVariateKLD, CMD, ReconLoss

logger = logging.getLogger('MSA')
class MyASRmodel_post_bert():
    def __init__(self, args):
        assert args.train_mode == 'regression'
        self.args = args
        self.args.tasks = "M"

        self.metrics = MetricsTop(args.train_mode).getMetics(args.datasetName)
        self.cre_mae = nn.L1Loss(reduction="mean")  # loss
        self.cre_IBLoss = IBLoss(self.args.beta)
        self.cre_Fine_ConLoss = Fine_ConLoss(temperature = self.args.temperature_F)
        self.cre_Coarse_SupConLoss = Coarse_SupConLoss(temperature = self.args.temperature_C, t_w = self.args.t_w, lamda = self.args.lamda)  # weightReconLoss()
        self.omega1 = args.omega1
        self.omega2 = args.omega2
        self.omega3 = args.omega3

    def do_train(self, model, dataloader):
        def count_parameters(model, name='.fusion'):
            answer = 0
            for n, p in model.named_parameters():
                if name in n:
                    answer += p.numel()
            return answer
        def count_parameters_2(model):
            answer = 0
            for n, p in model.named_parameters():
                if 'predictor' not in n and 'projector' not in n and 'recon' not in n:
                    answer += p.numel()
            return answer

        logger.info(f'The model during inference has {count_parameters_2(model)} parameters.')
        logger.info(f'The fusion module (CIR) has {count_parameters(model)} parameters.')


        if self.args.datasetName != "con_sims" and self.args.datasetName != "mosi":
            bert_no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
            bert_params = list(model.Model.text_model.named_parameters())
            #+ list(model.Model.detection_text_model.named_parameters()))

            # bert_params = list(model.Model.text_model.named_parameters())
            audio_params = list(model.Model.audio_model.named_parameters())
            video_params = list(model.Model.video_model.named_parameters())
            """
            multi-GPU 
            bert_no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
            bert_params = list(model.module.Model.text_model.named_parameters())#Model
            audio_params = list(model.module.Model.audio_model.named_parameters())
            video_params = list(model.module.Model.video_model.named_parameters())
            """

            bert_params_decay = [p for n, p in bert_params if not any(nd in n for nd in bert_no_decay)]
            bert_params_no_decay = [p for n, p in bert_params if any(nd in n for nd in bert_no_decay)]
            audio_params = [p for n, p in audio_params]
            video_params = [p for n, p in video_params]
            model_params_other = [p for n, p in list(model.Model.named_parameters()) if 'text_model' not in n and \
                                  'audio_model' not in n and 'video_model' not in n ]#and 'detection_text_model' not in n
            # model_params_other = [p for n, p in list(model.Model.named_parameters()) if 'text_model' not in n and \
            #                       'audio_model' not in n and 'video_model' not in n]
        else:
            bert_no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
            bert_params = list(model.Model.text_model.named_parameters())
            # bert_params = list(model.Model.text_model.named_parameters())
            audio_params = list(model.Model.audio_model.named_parameters())
            video_params = list(model.Model.video_model.named_parameters())
            """
            multi-GPU 
            bert_no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
            bert_params = list(model.module.Model.text_model.named_parameters())#Model
            audio_params = list(model.module.Model.audio_model.named_parameters())
            video_params = list(model.module.Model.video_model.named_parameters())
            """

            bert_params_decay = [p for n, p in bert_params if not any(nd in n for nd in bert_no_decay)]
            bert_params_no_decay = [p for n, p in bert_params if any(nd in n for nd in bert_no_decay)]
            audio_params = [p for n, p in audio_params]
            video_params = [p for n, p in video_params]
            model_params_other = [p for n, p in list(model.Model.named_parameters()) if 'text_model' not in n and \
                                  'audio_model' not in n and 'video_model' not in n]
            # model_params_other = [p for n, p in list(model.Model.named_parameters()) if 'text_model' not in n and \
            #                       'audio_model' not in n and 'video_model' not in n]


        optimizer_grouped_parameters = [
            {'params': bert_params_decay, 'weight_decay': self.args.weight_decay_bert, 'lr': self.args.learning_rate_bert},
            {'params': bert_params_no_decay, 'weight_decay': 0.0, 'lr': self.args.learning_rate_bert},
            {'params': audio_params, 'weight_decay': self.args.weight_decay_audio, 'lr': self.args.learning_rate_audio},
            {'params': video_params, 'weight_decay': self.args.weight_decay_video, 'lr': self.args.learning_rate_video},
            {'params': model_params_other, 'weight_decay': self.args.weight_decay_other, 'lr': self.args.learning_rate_other}
        ]
        optimizer = optim.AdamW(optimizer_grouped_parameters)
        # initilize results
        logger.info("Start training...")
        epochs, best_epoch = 0, 0
        min_or_max = 'min' if self.args.KeyEval in ['Loss'] else 'max'
        best_valid = 1e8 if min_or_max == 'min' else 0
        # loop util earlystop
        while True:
        #for epoch in range(1, self.args.num_epochs + 1):  # best_epoch=13
            epochs += 1
            # train
            y_pred, y_true = [], []
            model.train()
            train_loss = 0.0
            left_epochs = self.args.update_epochs
            s_t = time.time()
            # with tqdm(total=len(dataloader), desc='Train') as pbar:
            #     for batch_idx, batch_data in enumerate(dataloader):

            with tqdm(dataloader['train']) as td:
                for batch_idx, batch_data in enumerate(td, start=int(1)):
                    if left_epochs == self.args.update_epochs:
                        optimizer.zero_grad()
                    left_epochs -= 1
                    # complete view
                    vision = batch_data['vision'].to(self.args.device)
                    audio = batch_data['audio'].to(self.args.device)
                    text = batch_data['text'].to(self.args.device)


                    labels = batch_data['labels']['M'].to(self.args.device)

                    if not self.args.need_data_aligned:
                        #print(self.args.need_data_aligned)
                        audio_lengths = batch_data['audio_lengths'].to(self.args.device)
                        vision_lengths = batch_data['vision_lengths'].to(self.args.device)
                    else:
                        audio_lengths, vision_lengths = 0, 0

                    # forward
                    outputs = model(text, (audio, audio_lengths), (vision, vision_lengths))

                    # store results
                    y_pred.append(outputs['pred'].cpu())
                    y_true.append(labels.cpu())
                    # compute loss
                    ## prediction loss
                    loss_pred = self.cre_mae(outputs['pred'], labels)

                    ## cl loss
                    IBLoss_a = self.cre_IBLoss(outputs['output_a'], labels, outputs['mu_a'], outputs['std_a'])
                    IBLoss_v = self.cre_IBLoss(outputs['output_v'], labels, outputs['mu_v'], outputs['std_v'])

                    Loss_Fine_Con_at = self.cre_Fine_ConLoss(outputs['z_FCL_A'], outputs['z_FCL_T'])
                    Loss_Fine_Con_vt = self.cre_Fine_ConLoss(outputs['z_FCL_V'], outputs['z_FCL_T'])

                    Loss_Coarse_SupCon_at = self.cre_Coarse_SupConLoss(outputs['z_CCL_A'], outputs['z_CCL_T'], labels)
                    Loss_Coarse_SupCon_vt = self.cre_Coarse_SupConLoss(outputs['z_CCL_V'], outputs['z_CCL_T'], labels)

                    loss = loss_pred + self.omega1 * (IBLoss_a + IBLoss_v) + self.omega2 * (Loss_Fine_Con_at + Loss_Fine_Con_vt) +\
                    self.omega3 * (Loss_Coarse_SupCon_at + Loss_Coarse_SupCon_vt)

                    loss.backward()

                    if batch_idx % (len(td) // 2) == 0:
                        logger.info(f'Epoch {epochs} | Batch {batch_idx:>3d} | [Train] Loss {loss:.4f}')
                    train_loss += loss.item()

                    # update parameters
                    if not left_epochs:
                        # update
                        optimizer.step()
                        left_epochs = self.args.update_epochs
                if not left_epochs:
                    # update
                    optimizer.step()

            e_t = time.time()
            logger.info(f'One epoch time for training: {e_t - s_t:.3f}s.')

            train_loss = train_loss / len(dataloader['train'])
            pred, true = torch.cat(y_pred), torch.cat(y_true)
            train_results = self.metrics(pred, true)

            log_infos = [''] * 8
            log_infos[0] = log_infos[-1] = '-' * 100

            # validation
            s_t = time.time()

            val_results = self.do_test(model, dataloader['valid'],  mode="VAL", epochs=epochs)

            e_t = time.time()
            logger.info(f'One epoch time for validation: {e_t - s_t:.3f}s.')

            cur_valid = val_results[self.args.KeyEval]#self.args.KeyEval

            # save best model
            isBetter = cur_valid <= (best_valid - 1e-6) if min_or_max == 'min' else cur_valid >= (best_valid + 1e-6)
            if isBetter:
                best_valid, best_epoch = cur_valid, epochs
                self.best_epoch = best_epoch
                # save model
                torch.save(model.cpu().state_dict(), self.args.model_save_path)
                model.to(self.args.device)
                log_infos[5] = f'==> Note: achieve best [Val] results at epoch {best_epoch}'



            log_infos[1] = f"Seed {self.args.seed} ({self.args.seeds.index(self.args.seed) + 1}/{self.args.num_seeds}) " \
                       f"| Epoch {epochs} (early stop={epochs-best_epoch}) | Train Loss {train_loss:.4f} | Val Loss {val_results['Loss']:.4f}"
            log_infos[2] = f"[Train] {dict_to_str(train_results)}"
            log_infos[3] = f"  [Val] {dict_to_str(val_results)}"

            # log information
            for log_info in log_infos:
                if log_info: logger.info(log_info)

            # early stop
            if epochs - best_epoch >= self.args.early_stop:
                logger.info(f"==> Note: since '{self.args.KeyEval}' does not improve in the past {self.args.early_stop} epochs, early stop the training process!")
                return

    def do_test(self, model, dataloader, mode="VAL", epochs=None):
        if epochs is None: logger.info("=" * 30 + f"Start Test of Missing_Seed {self.args.missing_seed}" + "=" * 30)
        model.eval()
        y_pred, y_true = [], []
        eval_loss = 0.0
        eval_loss_pred = 0.0

        with torch.no_grad():
            with tqdm(dataloader) as td:
                for batch_idx, batch_data in enumerate(td, 1):
                    vision = batch_data['vision'].to(self.args.device)
                    audio = batch_data['audio'].to(self.args.device)
                    text = batch_data['text'].to(self.args.device)

                    labels = batch_data['labels']['M'].to(self.args.device)

                    if not self.args.need_data_aligned:
                        # print(self.args.need_data_aligned)
                        audio_lengths = batch_data['audio_lengths'].to(self.args.device)
                        vision_lengths = batch_data['vision_lengths'].to(self.args.device)
                    else:
                        audio_lengths, vision_lengths = 0, 0

                    # forward
                    outputs = model(text, (audio, audio_lengths), (vision, vision_lengths))
                    # store results
                    y_pred.append(outputs['pred'].cpu())
                    y_true.append(labels.cpu())
                    # compute loss
                    ## prediction loss
                    loss_pred =self.cre_mae(outputs['pred'], labels)
                    ## sup loss
                    ## cl loss
                    IBLoss_a = self.cre_IBLoss(outputs['pred'], labels, outputs['mu_a'], outputs['std_a'])
                    IBLoss_v = self.cre_IBLoss(outputs['pred'], labels, outputs['mu_v'], outputs['std_v'])

                    Loss_Fine_Con_at = self.cre_Fine_ConLoss(outputs['z_FCL_A'], outputs['z_FCL_T'])
                    Loss_Fine_Con_vt = self.cre_Fine_ConLoss(outputs['z_FCL_V'], outputs['z_FCL_T'])

                    Loss_Coarse_SupCon_at = self.cre_Coarse_SupConLoss(outputs['z_CCL_A'], outputs['z_CCL_T'], labels)
                    Loss_Coarse_SupCon_vt = self.cre_Coarse_SupConLoss(outputs['z_CCL_V'], outputs['z_CCL_T'], labels)

                    loss = loss_pred + self.omega1 * (IBLoss_a + IBLoss_v) + self.omega2 * (Loss_Fine_Con_at + Loss_Fine_Con_vt) + \
                           self.omega3 * (Loss_Coarse_SupCon_at + Loss_Coarse_SupCon_vt)
                    #loss = loss_pred

                    if batch_idx % (len(td) // 2) == 0:
                        logger.info(f'Epoch {epochs} | Batch {batch_idx:>3d} | [Val] Loss {loss:.4f}')
                    eval_loss += loss.item()

                    y_pred.append(outputs['pred'].cpu())
                    y_true.append(labels.cpu())

        eval_loss = eval_loss / len(dataloader)

        # logger.info(mode+"-(%s)" % self.args.modelName + " >> loss: %.4f " % eval_loss)
        pred, true = torch.cat(y_pred), torch.cat(y_true)
        eval_results = self.metrics(pred, true)
        # logger.info('M: >> ' + dict_to_str(eval_results))
        eval_results['Loss'] = eval_loss


        if epochs is None: # for TEST
            logger.info(f"\n [Test] {dict_to_str(eval_results)}")
            logger.info(f"==> Note: achieve this results at epoch {self.best_epoch} (best [Val]) / {getattr(self, 'best_test_epoch', None)} (best [Test])")
        return eval_results

