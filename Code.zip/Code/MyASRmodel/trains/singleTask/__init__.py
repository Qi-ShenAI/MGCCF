# from trains.missingTask.TFR_NET import TFR_NET
# from trains.missingTask.EMT_DLFR import EMT_DLFR
#
# __all__ = ['TFR_NET', 'EMT_DLFR']

from trains.singleTask.CIR import CIRP
from trains.singleTask.MyASRmodel_post_bert import MyASRmodel_post_bert
from trains.singleTask.Mymodel_post_bert import Mymodel_post_bert
from trains.singleTask.MyASRmodel import MyASRmodel
from trains.singleTask.Mymodel import Mymodel
from trains.singleTask.SWRM import SWRM
from trains.singleTask.SWRMbase import SWRMbase
from trains.singleTask.MULT import MULT
from trains.singleTask.MISA import MISA
from trains.singleTask.MyASRmodel_post_bert_Wo_CUCL import MyASRmodel_post_bert_Wo_CUCL
from trains.singleTask.MyASRmodel_post_bert_Wo_FTCL import MyASRmodel_post_bert_Wo_FTCL
from trains.singleTask.MyASRmodel_post_bert_Wo_IB import MyASRmodel_post_bert_Wo_IB
from trains.singleTask.MyASRmodel_post_bert_Wo_GCI import MyASRmodel_post_bert_Wo_GCI
from trains.singleTask.MyASRmodel_post_bert_Wo_MICF import MyASRmodel_post_bert_Wo_MICF
from trains.singleTask.Mymodel_Wo_CUCL import Mymodel_Wo_CUCL
from trains.singleTask.Mymodel_Wo_FTCL import Mymodel_Wo_FTCL
from trains.singleTask.Mymodel_Wo_IB import Mymodel_Wo_IB
from trains.singleTask.Mymodel_Wo_GCI import Mymodel_Wo_GCI
from trains.singleTask.Mymodel_Wo_MICF import Mymodel_Wo_MICF
__ALL__ = ['CIRP','MyASRmodel_post_bert','Mymodel_post_bert','MyASRmodel','Mymodel','SWRM','SWRMbase','MULT','MISA','MyASRmodel_post_bert_Wo_CUCL','MyASRmodel_post_bert_Wo_FTCL',\
          'MyASRmodel_post_bert_Wo_IB', 'MyASRmodel_post_bert_Wo_GCI', 'MyASRmodel_post_bert_Wo_MICF', 'Mymodel_Wo_CUCL', 'Mymodel_Wo_FTCL', 'Mymodel_Wo_IB', 'Mymodel_Wo_GCI', 'Mymodel_Wo_MICF']
#__ALL__ = ['TFR_NET', 'EMT_DLFR']